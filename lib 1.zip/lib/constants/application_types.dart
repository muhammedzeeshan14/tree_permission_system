class ApplicationTypes {
  ApplicationTypes._();

  static const privateLand = "PL";

  static const governmentLand = "GL";

  static const mcc = "MCC";

  static const sandal = "SANDAL";
}