import 'dart:io';

import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import 'package:flutter/foundation.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();

  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;

    _database = await _initDB();

    return _database!;
  }

  Future<Database> _initDB() async {
    final dbPath = await getDatabasesPath();

debugPrint("DB PATH: $dbPath");

final path = join(dbPath, "tpms.db");

debugPrint("DB FILE: $path");

print("DATABASE PATH = $path");

    return await openDatabase(
      path,
    version: 12,

      onCreate: _createDB,
 onUpgrade: _onUpgrade,
    );
  }

  Future<void> _createDB(Database db, int version) async {
    await db.execute('''
CREATE TABLE users(

id INTEGER PRIMARY KEY AUTOINCREMENT,

name TEXT,

username TEXT,

password TEXT,

role TEXT,

sectionId INTEGER,

beatId INTEGER,

isActive INTEGER

)
''');

    await db.execute('''
CREATE TABLE applications(

id INTEGER PRIMARY KEY AUTOINCREMENT,

officeNumber TEXT,

applicationType TEXT,

verifiedApplicationType TEXT,

permissionTypeId INTEGER,

permissionType TEXT,

applicationDate TEXT,

receivedDate TEXT,

applicantName TEXT,

applicantAddress TEXT,

treeLocationSame INTEGER DEFAULT 1,

treeLocationAddress TEXT,

mobile TEXT,

applicationSource TEXT,

forwardedDate TEXT,

sectionId INTEGER,

beatId INTEGER,

purpose TEXT,

gps TEXT,

inspectionStarted INTEGER,
inspectionDecision TEXT,

overallRemarks TEXT,

bfoVerificationDate TEXT,

drfoInspectionDate TEXT,

drfoOverallRemarks TEXT,

rfoInspectionStarted INTEGER,

rfoInspectionDate TEXT,

rfoOverallRemarks TEXT,

returnReason TEXT,

returnRemarks TEXT,

returnedBy TEXT,

returnedDate TEXT,

status TEXT,

inspectionMode TEXT,

treeCountSiteDetails TEXT,

createdDate TEXT,

rfoApprovalDate TEXT,

createdBy INTEGER,

assignedBFO INTEGER,

assignedDRFO INTEGER,

lastTreeNumber INTEGER DEFAULT 0

)
''');

    await db.execute('''
CREATE TABLE trees(

id INTEGER PRIMARY KEY AUTOINCREMENT,

applicationId INTEGER,

treeNumber TEXT,

baseTreeNumber INTEGER,

stemType TEXT,

stemLetter TEXT,

stemSequence INTEGER,

isLastStem INTEGER DEFAULT 1,

speciesId INTEGER,

recommendationTypeId INTEGER,

gbh REAL,

height REAL,

notFitForTimber INTEGER DEFAULT 0,

numberOfBranches INTEGER,

numberOfTwigs INTEGER,

firewood REAL,

recommendationReasonIds TEXT,

remarks TEXT

)
''');



    await db.execute('''
CREATE TABLE section_master(

id INTEGER PRIMARY KEY AUTOINCREMENT,

sectionName TEXT,

displayOrder INTEGER,

isActive INTEGER

)
''');

    await db.execute('''
CREATE TABLE beat_master(

id INTEGER PRIMARY KEY AUTOINCREMENT,

sectionId INTEGER,

beatName TEXT,

displayOrder INTEGER,

isActive INTEGER

)
''');

    await db.execute('''
CREATE TABLE master_data(

id INTEGER PRIMARY KEY AUTOINCREMENT,

masterType TEXT,

value TEXT,

code TEXT,

parentCode TEXT,

displayOrder INTEGER,

remarks TEXT,

isActive INTEGER

)
''');
await db.execute('''
CREATE TABLE application_history(

id INTEGER PRIMARY KEY AUTOINCREMENT,

officeNumber TEXT,

action TEXT,

remarks TEXT,

actionBy TEXT,

actionDate TEXT

)
''');
await db.execute('''

CREATE TABLE office_configuration(

id INTEGER PRIMARY KEY AUTOINCREMENT,

rangeName TEXT,

rangeCode TEXT,

officePrefix TEXT,

financialYear TEXT,

rangeOfficeAddress TEXT,

division TEXT,

subDivision TEXT

)

''');
await db.execute('''

CREATE TABLE application_type_master(

id INTEGER PRIMARY KEY AUTOINCREMENT,

applicationType TEXT,

shortCode TEXT,

displayOrder INTEGER,

isActive INTEGER

)

''');

await db.execute('''

CREATE TABLE permission_type_master(

id INTEGER PRIMARY KEY AUTOINCREMENT,

permissionType TEXT,

displayOrder INTEGER,

isActive INTEGER

)

''');

await db.execute('''

CREATE TABLE application_type_permission_mapping(

id INTEGER PRIMARY KEY AUTOINCREMENT,

applicationTypeId INTEGER,

permissionTypeId INTEGER

)

''');

await db.execute("""

CREATE TABLE application_tree_count_site(

id INTEGER PRIMARY KEY AUTOINCREMENT,

applicationId INTEGER NOT NULL,

siteDetails TEXT,

displayOrder INTEGER NOT NULL

)

""");

await db.execute("""

CREATE TABLE application_tree_count(

id INTEGER PRIMARY KEY AUTOINCREMENT,

siteId INTEGER NOT NULL,

speciesId INTEGER NOT NULL,

treeCount INTEGER NOT NULL,

displayOrder INTEGER NOT NULL

)

""");

await db.execute("""

CREATE TABLE application_mahazar(

id INTEGER PRIMARY KEY AUTOINCREMENT,

applicationId INTEGER NOT NULL,

mahazarDate TEXT,

startTime TEXT,

startTimeManual TEXT,

endTime TEXT,

endTimeManual TEXT,

northBoundary TEXT,

eastBoundary TEXT,

southBoundary TEXT,

westBoundary TEXT

)

""");

await db.execute("""

CREATE TABLE revenue_opinion_master(

id INTEGER PRIMARY KEY AUTOINCREMENT,

revenueOpinion TEXT,

code TEXT,

officeName TEXT,

officeAddress TEXT,

remarks TEXT,

displayOrder INTEGER,

isActive INTEGER

)

""");

await db.execute("""

CREATE TABLE forwarded_source_master(

id INTEGER PRIMARY KEY AUTOINCREMENT,

sourceName TEXT,

shortCode TEXT,

displayOrder INTEGER,

isActive INTEGER

)

""");

await db.execute("""

CREATE TABLE inspection_photos(

id INTEGER PRIMARY KEY AUTOINCREMENT,

applicationId INTEGER,

treeId INTEGER,

photoPath TEXT,

caption TEXT,

createdDate TEXT

)

""");
await db.execute("""

CREATE TABLE inspection_documents(

id INTEGER PRIMARY KEY AUTOINCREMENT,

applicationId INTEGER,

documentName TEXT,

filePath TEXT,

remarks TEXT,

createdDate TEXT

)

""");

await db.execute("""

CREATE TABLE inspection_defer_reason_master(

id INTEGER PRIMARY KEY AUTOINCREMENT,

reason TEXT,

displayOrder INTEGER,

isActive INTEGER

)

""");

await db.execute("""

CREATE TABLE inspection_deferred_reasons(

id INTEGER PRIMARY KEY AUTOINCREMENT,

applicationId INTEGER,

reasonId INTEGER,

reasonName TEXT,

displayOrder INTEGER

)

""");

await db.execute("""

CREATE TABLE application_verifications(

applicationId INTEGER PRIMARY KEY,

applicationTypeCorrect INTEGER,

gpsCorrect INTEGER,

photosCorrect INTEGER,

documentsCorrect INTEGER,

applicationTypeReason TEXT,

gpsReason TEXT,

photosReason TEXT,

documentsReason TEXT,

verifiedBy TEXT,

verifiedDate TEXT

)

""");

await db.execute("""

CREATE TABLE application_forward_references(

id INTEGER PRIMARY KEY AUTOINCREMENT,

applicationId INTEGER,

sourceId INTEGER,

referenceNumber TEXT,

referenceDate TEXT,

displayOrder INTEGER

)

""");

await db.execute("""

CREATE TABLE tree_verifications(

treeId INTEGER PRIMARY KEY,
verification TEXT,
verificationReason TEXT,
verifiedBy TEXT,
verifiedDate TEXT

)

""");

await db.execute("""

CREATE TABLE application_revenue_opinion(

id INTEGER PRIMARY KEY AUTOINCREMENT,

applicationId INTEGER,

revenueOpinionId INTEGER

)

""");

await _createTreeCountVerificationTable(db);
await _createRevenueOpinionVerificationTable(db);
await _createMahazarVerificationTable(db);
await seedDevelopmentData(db);
  }

Future<void> _onUpgrade(
  Database db,
  int oldVersion,
  int newVersion,
) async {

  if (oldVersion < 5) {

    await db.execute("""

CREATE TABLE IF NOT EXISTS application_tree_count_site(

id INTEGER PRIMARY KEY AUTOINCREMENT,

applicationId INTEGER NOT NULL,

siteDetails TEXT,

displayOrder INTEGER NOT NULL

)

""");

await db.execute("""

CREATE TABLE IF NOT EXISTS application_tree_count(

id INTEGER PRIMARY KEY AUTOINCREMENT,

siteId INTEGER NOT NULL,

speciesId INTEGER NOT NULL,

treeCount INTEGER NOT NULL,

displayOrder INTEGER NOT NULL

)

""");

await db.execute("""

CREATE TABLE IF NOT EXISTS application_mahazar(

id INTEGER PRIMARY KEY AUTOINCREMENT,

applicationId INTEGER NOT NULL,

mahazarDate TEXT,

startTime TEXT,

startTimeManual TEXT,

endTime TEXT,

endTimeManual TEXT,

northBoundary TEXT,
eastBoundary TEXT,

southBoundary TEXT,

westBoundary TEXT

)

""");

    await db.execute("""

CREATE TABLE IF NOT EXISTS forwarded_source_master(

id INTEGER PRIMARY KEY AUTOINCREMENT,

sourceName TEXT,

shortCode TEXT,

displayOrder INTEGER,

isActive INTEGER

)

""");

    await db.execute("""

CREATE TABLE IF NOT EXISTS application_forward_references(

id INTEGER PRIMARY KEY AUTOINCREMENT,

applicationId INTEGER,

sourceId INTEGER,

referenceNumber TEXT,

referenceDate TEXT,

displayOrder INTEGER

)

""");

    final count = Sqflite.firstIntValue(
      await db.rawQuery(
        "SELECT COUNT(*) FROM forwarded_source_master",
      ),
    ) ?? 0;

    if (count == 0) {

      final sources = [
        {"sourceName":"DCF Office","shortCode":"DCF","displayOrder":1,"isActive":1},
        {"sourceName":"ACF Office","shortCode":"ACF","displayOrder":2,"isActive":1},
        {"sourceName":"MCC","shortCode":"MCC","displayOrder":3,"isActive":1},
        {"sourceName":"MUDA","shortCode":"MUDA","displayOrder":4,"isActive":1},
        {"sourceName":"NHAI","shortCode":"NHAI","displayOrder":5,"isActive":1},
        {"sourceName":"BESCOM","shortCode":"BESCOM","displayOrder":6,"isActive":1},
        {"sourceName":"KPTCL","shortCode":"KPTCL","displayOrder":7,"isActive":1},
        {"sourceName":"PWD","shortCode":"PWD","displayOrder":8,"isActive":1},
        {"sourceName":"Gram Panchayat","shortCode":"GP","displayOrder":9,"isActive":1},
        {"sourceName":"Taluk Office","shortCode":"TALUK","displayOrder":10,"isActive":1},
        {"sourceName":"Deputy Commissioner's Office","shortCode":"DC","displayOrder":11,"isActive":1},
        {"sourceName":"Others","shortCode":"OTHER","displayOrder":12,"isActive":1},
      ];

      for (final source in sources) {
        await db.insert(
          "forwarded_source_master",
          source,
        );
      }
    }
  }

if (oldVersion < 7) {

  await db.execute("""

ALTER TABLE trees

ADD COLUMN notFitForTimber INTEGER DEFAULT 0

""");

}

if (oldVersion < 8) {

  await db.execute("""

CREATE TABLE IF NOT EXISTS revenue_opinion_master(

id INTEGER PRIMARY KEY AUTOINCREMENT,

revenueOpinion TEXT,

code TEXT,

officeName TEXT,

officeAddress TEXT,

remarks TEXT,

displayOrder INTEGER,

isActive INTEGER

)

""");

}

if (oldVersion < 9) {

  await db.execute("""

CREATE TABLE application_revenue_opinion(

id INTEGER PRIMARY KEY AUTOINCREMENT,

applicationId INTEGER,

revenueOpinionId INTEGER

)

""");

}

if (oldVersion < 10) {

  await _createTreeCountVerificationTable(db);

}

if (oldVersion < 11) {

  await _createRevenueOpinionVerificationTable(db);

}

if (oldVersion < 12) {

  await _createMahazarVerificationTable(db);

}

}

Future<void> _createTreeCountVerificationTable(
    Database db) async {

  await db.execute("""

CREATE TABLE tree_count_verification(

id INTEGER PRIMARY KEY AUTOINCREMENT,

applicationId INTEGER,

verification TEXT,

reason TEXT,

verifiedBy TEXT,

verifiedDate TEXT

)

""");

}

Future<void> _createRevenueOpinionVerificationTable(
    Database db) async {

  await db.execute("""

CREATE TABLE revenue_opinion_verification(

id INTEGER PRIMARY KEY AUTOINCREMENT,

applicationId INTEGER,

verification TEXT,

reason TEXT,

verifiedBy TEXT,

verifiedDate TEXT

)

""");

}

Future<void> _createMahazarVerificationTable(
    Database db) async {

  await db.execute("""

CREATE TABLE mahazar_verification(

id INTEGER PRIMARY KEY AUTOINCREMENT,

applicationId INTEGER,

verification TEXT,

reason TEXT,

verifiedBy TEXT,

verifiedDate TEXT

)

""");

}

Future<void> seedDevelopmentData(Database db) async {

  // =====================================================
  // OFFICE CONFIGURATION
  // =====================================================

  await db.insert(
    "office_configuration",
    {
      "rangeName": "Mysuru Range",
      "rangeCode": "MYR",
      "officePrefix": "MYR",
      "financialYear": "2026-27",
      "rangeOfficeAddress": "Range Forest Office, Mysuru",
      "division": "Mysuru Division",
      "subDivision": "Mysuru Sub Division",
    },
  );

  // =====================================================
  // USERS
  // =====================================================

  final users = [

    {
      "name": "System Administrator",
      "username": "admin",
      "password": "admin123",
      "role": "RFO",
      "sectionId": null,
      "beatId": null,
      "isActive": 1,
    },

    {
      "name": "Range Forest Officer",
      "username": "rfo",
      "password": "1234",
      "role": "RFO",
      "sectionId": null,
      "beatId": null,
      "isActive": 1,
    },

    {
      "name": "Deputy Range Forest Officer",
      "username": "drfo",
      "password": "1234",
      "role": "DRFO",
      "sectionId": 1,
      "beatId": null,
      "isActive": 1,
    },

    {
      "name": "Beat Forest Officer",
      "username": "bfo1",
      "password": "1234",
      "role": "BFO",
      "sectionId": 1,
      "beatId": 1,
      "isActive": 1,
    },

    {
      "name": "Case Worker",
      "username": "caseworker",
      "password": "1234",
      "role": "Case Worker",
      "sectionId": null,
      "beatId": null,
      "isActive": 1,
    },

  ];

  for (final user in users) {
    await db.insert("users", user);
  }

  // =====================================================
  // SECTIONS
  // =====================================================

  await db.insert(
    "section_master",
    {
      "sectionName": "Mysuru Urban",
      "displayOrder": 1,
      "isActive": 1,
    },
  );

  await db.insert(
    "section_master",
    {
      "sectionName": "Mysuru Rural",
      "displayOrder": 2,
      "isActive": 1,
    },
  );

  // =====================================================
  // BEATS
  // =====================================================

  final beats = [

    {
      "sectionId": 1,
      "beatName": "Nazarbad",
      "displayOrder": 1,
      "isActive": 1,
    },

    {
      "sectionId": 1,
      "beatName": "Siddarthanagar",
      "displayOrder": 2,
      "isActive": 1,
    },

    {
      "sectionId": 2,
      "beatName": "Chamundi",
      "displayOrder": 1,
      "isActive": 1,
    },

    {
      "sectionId": 2,
      "beatName": "Yelwala",
      "displayOrder": 2,
      "isActive": 1,
    },

  ];

  for (final beat in beats) {
    await db.insert("beat_master", beat);
  }

  // =====================================================
  // APPLICATION TYPES
  // =====================================================

 final applicationTypes = [

  {
    "applicationType": "Government Land",
    "shortCode": "GL",
    "displayOrder": 1,
    "isActive": 1,
  },

  {
    "applicationType": "Private Land",
    "shortCode": "PL",
    "displayOrder": 2,
    "isActive": 1,
  },

  {
    "applicationType": "RTC Entry",
    "shortCode": "RTC",
    "displayOrder": 3,
    "isActive": 1,
  },

  {
    "applicationType": "MCC",
    "shortCode": "MCC",
    "displayOrder": 4,
    "isActive": 1,
  },

  {
    "applicationType": "Sandal Government",
    "shortCode": "SGL",
    "displayOrder": 5,
    "isActive": 1,
  },

  {
    "applicationType": "Sandal Private",
    "shortCode": "SPL",
    "displayOrder": 6,
    "isActive": 1,
  },

];

  for (final type in applicationTypes) {
    await db.insert(
      "application_type_master",
      type,
    );
  }

// =====================================================
// PERMISSION TYPES
// =====================================================

final permissionTypes = [

  {
    "permissionType": "Permission",
    "displayOrder": 1,
    "isActive": 1,
  },

  {
    "permissionType": "Valuation",
    "displayOrder": 2,
    "isActive": 1,
  },

  {
    "permissionType": "Tree Count",
    "displayOrder": 3,
    "isActive": 1,
  },

  {
    "permissionType": "Forward to Tree Officer",
    "displayOrder": 4,
    "isActive": 1,
  },

  {
    "permissionType": "Auction",
    "displayOrder": 5,
    "isActive": 1,
  },

  {
    "permissionType": "Sandal Depot",
    "displayOrder": 6,
    "isActive": 1,
  },

];

for (final permission in permissionTypes) {

  await db.insert(
    "permission_type_master",
    permission,
  );

}

// =====================================================
// DEFAULT APPLICATION TYPE → PERMISSION TYPE MAPPING
// =====================================================

await db.insert(
  "application_type_permission_mapping",
  {
    "applicationTypeId": 1,
    "permissionTypeId": 1, // Government Land → Permission
  },
);

await db.insert(
  "application_type_permission_mapping",
  {
    "applicationTypeId": 2,
    "permissionTypeId": 1, // Private Land → Permission
  },
);

await db.insert(
  "application_type_permission_mapping",
  {
    "applicationTypeId": 3,
    "permissionTypeId": 3, // RTC Entry → Tree Count
  },
);

await db.insert(
  "application_type_permission_mapping",
  {
    "applicationTypeId": 4,
    "permissionTypeId": 1, // MCC → Permission
  },
);

await db.insert(
  "application_type_permission_mapping",
  {
    "applicationTypeId": 5,
    "permissionTypeId": 6, // Sandal Government → Sandal Depot
  },
);

await db.insert(
  "application_type_permission_mapping",
  {
    "applicationTypeId": 6,
    "permissionTypeId": 2, // Sandal Private → Valuation
  },
);

  // =====================================================
// FORWARDED SOURCES
// =====================================================

final forwardedSources = [

  {
    "sourceName": "DCF Office",
    "shortCode": "DCF",
    "displayOrder": 1,
    "isActive": 1,
  },

  {
    "sourceName": "ACF Office",
    "shortCode": "ACF",
    "displayOrder": 2,
    "isActive": 1,
  },

  {
    "sourceName": "MCC",
    "shortCode": "MCC",
    "displayOrder": 3,
    "isActive": 1,
  },

  {
    "sourceName": "MUDA",
    "shortCode": "MUDA",
    "displayOrder": 4,
    "isActive": 1,
  },

  {
    "sourceName": "NHAI",
    "shortCode": "NHAI",
    "displayOrder": 5,
    "isActive": 1,
  },

  {
    "sourceName": "BESCOM",
    "shortCode": "BESCOM",
    "displayOrder": 6,
    "isActive": 1,
  },

  {
    "sourceName": "KPTCL",
    "shortCode": "KPTCL",
    "displayOrder": 7,
    "isActive": 1,
  },

  {
    "sourceName": "PWD",
    "shortCode": "PWD",
    "displayOrder": 8,
    "isActive": 1,
  },

  {
    "sourceName": "Gram Panchayat",
    "shortCode": "GP",
    "displayOrder": 9,
    "isActive": 1,
  },

  {
    "sourceName": "Taluk Office",
    "shortCode": "TALUK",
    "displayOrder": 10,
    "isActive": 1,
  },

  {
    "sourceName": "Deputy Commissioner's Office",
    "shortCode": "DC",
    "displayOrder": 11,
    "isActive": 1,
  },

  {
    "sourceName": "Others",
    "shortCode": "OTHER",
    "displayOrder": 12,
    "isActive": 1,
  },

];

for (final source in forwardedSources) {

  await db.insert(
    "forwarded_source_master",
    source,
  );

}

// =====================================================
// INSPECTION DEFER REASONS
// =====================================================

final deferReasons = [

  {
    "reason": "Applicant Absent",
    "displayOrder": 1,
    "isActive": 1,
  },

  {
    "reason": "Heavy Rain",
    "displayOrder": 2,
    "isActive": 1,
  },

  {
    "reason": "Site Not Accessible",
    "displayOrder": 3,
    "isActive": 1,
  },

  {
    "reason": "Documents Not Available",
    "displayOrder": 4,
    "isActive": 1,
  },

  {
    "reason": "Owner Requested Postponement",
    "displayOrder": 5,
    "isActive": 1,
  },

  {
    "reason": "Law & Order Situation",
    "displayOrder": 6,
    "isActive": 1,
  },

  {
    "reason": "Court Stay",
    "displayOrder": 7,
    "isActive": 1,
  },

  {
    "reason": "Other",
    "displayOrder": 8,
    "isActive": 1,
  },

];

for (final reason in deferReasons) {

  await db.insert(
    "inspection_defer_reason_master",
    reason,
  );

}

}
}