import 'package:flutter/material.dart';

import '../models/tree_model.dart';

class TreeInspectionTable extends StatelessWidget {
  final List<TreeModel> trees;

  final Map<int, String> speciesMap;
  final Map<int, String> recommendationTypeMap;
  final Map<int, String> recommendationReasonMap;

  final bool showVerification;

  final Widget Function(TreeModel tree)? verificationBuilder;

  const TreeInspectionTable({
    super.key,
    required this.trees,
    required this.speciesMap,
    required this.recommendationTypeMap,
    required this.recommendationReasonMap,
    this.showVerification = false,
    this.verificationBuilder,
  });

String _recommendationName(TreeModel tree) {
  return recommendationTypeMap[
          tree.recommendationTypeId] ??
      "-";
}

String _recommendationReasons(TreeModel tree) {

  List<String> reasons = tree.recommendationReasonIds

      .map((id) => recommendationReasonMap[id] ?? "")

      .where((e) => e.isNotEmpty)

      .toList();

  if (tree.notFitForTimber) {

    reasons.add("Not Fit For Timber");

  }

  if (reasons.isEmpty) {

    return "-";

  }

  return reasons.join(", ");

}

Widget headerCell(String text) {
  return Padding(
    padding: const EdgeInsets.all(8),
    child: Text(
      text,
      textAlign: TextAlign.center,
      style: const TextStyle(
        fontWeight: FontWeight.bold,
      ),
    ),
  );
}

Widget tableCell(String text) {
  return Padding(
    padding: const EdgeInsets.all(8),
    child: Text(
      text,
      textAlign: TextAlign.center,
    ),
  );
}

@override
Widget build(BuildContext context) {
  return Scrollbar(
  thumbVisibility: true,
  child: SingleChildScrollView(
    scrollDirection: Axis.vertical,
    child: SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Table(
      border: TableBorder.all(),
      defaultVerticalAlignment:
          TableCellVerticalAlignment.middle,
      columnWidths: {
        0: const FixedColumnWidth(40),
        1: const FixedColumnWidth(50),
        2: const FixedColumnWidth(120),
        3: const FixedColumnWidth(60),
        4: const FixedColumnWidth(80),
        5: const FixedColumnWidth(100),
        6: const FixedColumnWidth(100),
        7: const FixedColumnWidth(150),
        8: const FixedColumnWidth(150),
        9: const FixedColumnWidth(150),

        if (showVerification)
          10: const FixedColumnWidth(200),
      },
      children: [
        TableRow(
          decoration: const BoxDecoration(
            color: Color(0xffE8F5E9),
          ),
          children: [
            headerCell("Sl"),
            headerCell("Tree No"),
            headerCell("Species"),
            headerCell("GBH"),
            headerCell("Height"),
            headerCell("Branch/Twig"),
            headerCell("Firewood"),
            headerCell("Recommendation"),
            headerCell("Reason"),
            headerCell("Remarks"),

            if (showVerification)
              headerCell("Verification"),
          ],
        ),

        ...List.generate(trees.length, (index) {
          final tree = trees[index];

          return TableRow(
            children: [
              tableCell("${index + 1}"),
              tableCell(tree.treeNumber),
              tableCell(
                  speciesMap[tree.speciesId] ?? ""),
              tableCell(
                  tree.gbh?.toString() ?? "-"),
              tableCell(
                  tree.height?.toString() ?? "-"),

              tableCell(
                tree.numberOfBranches != null
                    ? tree.numberOfBranches.toString()
                    : tree.numberOfTwigs != null
                        ? tree.numberOfTwigs.toString()
                        : "-",
              ),

              tableCell(tree.firewood.toString()),

              tableCell(
                  _recommendationName(tree)),

              tableCell(
                  _recommendationReasons(tree)),

              tableCell(
                tree.remarks.isEmpty
                    ? "-"
                    : tree.remarks,
              ),

              if (showVerification)
                verificationBuilder != null
                    ? verificationBuilder!(tree)
                    : const SizedBox(),
            ],
          );
        }),
            ],
    ),
  ),
),
);
}

}