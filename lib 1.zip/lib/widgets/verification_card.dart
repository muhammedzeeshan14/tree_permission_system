import 'package:flutter/material.dart';

class VerificationCard extends StatelessWidget {
  final String title;
  final String value;

  // null = Not verified
  // true = Correct
  // false = Re-inspect
  final bool? verification;

  final ValueChanged<bool?> onChanged;

  final String? selectedReason;

  final List<String> reasons;

  final ValueChanged<String?>? onReasonChanged;

  final VoidCallback? onView;

  const VerificationCard({
    super.key,
    required this.title,
    required this.value,
    required this.verification,
    required this.onChanged,
    this.selectedReason,
    this.reasons = const [],
    this.onReasonChanged,
    this.onView,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      child: Padding(
  padding: const EdgeInsets.all(12),
  child: IntrinsicHeight(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [

            Text(
              title,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),

            const SizedBox(height: 8),

            Text(value),

            if (onView != null) ...[
              const SizedBox(height: 8),

              Align(
  alignment: Alignment.centerLeft,
  child: OutlinedButton.icon(
    icon: const Icon(Icons.visibility),
    label: const Text("View"),
    onPressed: onView,
  ),
),
            ],

           RadioListTile<bool>(
  dense: true,
  visualDensity: VisualDensity.compact,
              contentPadding:
                  EdgeInsets.zero,
              value: true,
              groupValue: verification,
              title: const Text(
                "Correct",
              ),
              onChanged: onChanged,
            ),

            RadioListTile<bool>(
  dense: true,
  visualDensity: VisualDensity.compact,
              contentPadding:
                  EdgeInsets.zero,
              value: false,
              groupValue: verification,
              title: const Text(
                "Re-inspect",
              ),
              onChanged: onChanged,
            ),

            if (verification == false) ...[
              const SizedBox(height: 8),

              DropdownButtonFormField<String>(
                value: selectedReason,
                decoration:
                    const InputDecoration(
                  labelText:
                      "Verification Reason",
                  border:
                      OutlineInputBorder(),
                  isDense: true,
                ),
                items: reasons
                    .map(
                      (reason) =>
                          DropdownMenuItem(
                        value: reason,
                        child: Text(reason),
                      ),
                    )
                    .toList(),
                onChanged:
                    onReasonChanged,
              ),
            ],
                    ],
        ),
      ),
    ),
    );
  }
}