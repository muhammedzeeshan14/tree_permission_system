class MahazarModel {

  int? id;

  int applicationId;

  String mahazarDate;

  String startTime;

String startTimeManual;

String endTime;

String endTimeManual;

  String northBoundary;

  String eastBoundary;

  String southBoundary;

  String westBoundary;

  MahazarModel({

    this.id,

    required this.applicationId,

    this.mahazarDate = "",

    this.startTime = "",

this.startTimeManual = "",

this.endTime = "",

this.endTimeManual = "",

    this.northBoundary = "",

    this.eastBoundary = "",

    this.southBoundary = "",

    this.westBoundary = "",

  });

  Map<String, dynamic> toMap() {

    return {

      "id": id,

      "applicationId": applicationId,

      "mahazarDate": mahazarDate,

      "startTime": startTime,

"startTimeManual": startTimeManual,

"endTime": endTime,

"endTimeManual": endTimeManual,

      "northBoundary": northBoundary,

      "eastBoundary": eastBoundary,

      "southBoundary": southBoundary,

      "westBoundary": westBoundary,

    };

  }

  factory MahazarModel.fromMap(
      Map<String, dynamic> map) {

    return MahazarModel(

      id: map["id"],

      applicationId: map["applicationId"],

      mahazarDate:
          map["mahazarDate"] ?? "",

          startTime:
    map["startTime"] ?? "",

startTimeManual:
    map["startTimeManual"] ?? "",

endTime:
    map["endTime"] ?? "",

endTimeManual:
    map["endTimeManual"] ?? "",

      northBoundary:
          map["northBoundary"] ?? "",

      eastBoundary:
          map["eastBoundary"] ?? "",

      southBoundary:
          map["southBoundary"] ?? "",

      westBoundary:
          map["westBoundary"] ?? "",

    );

  }

}