import 'package:flutter/material.dart';

import '../../repositories/office_configuration_repository.dart';

class OfficeConfigurationScreen extends StatefulWidget {
  const OfficeConfigurationScreen({super.key});

  @override
  State<OfficeConfigurationScreen> createState() =>
      _OfficeConfigurationScreenState();
}

class _OfficeConfigurationScreenState
    extends State<OfficeConfigurationScreen> {

  final rangeNameController = TextEditingController();

  final rangeCodeController = TextEditingController();

  final officePrefixController = TextEditingController();

  final financialYearController = TextEditingController();

  final officeAddressController = TextEditingController();

  final divisionController = TextEditingController();

  final subDivisionController = TextEditingController();

  @override
  void initState() {
    super.initState();
    loadData();
  }

  Future<void> loadData() async {

    final data =
        await OfficeConfigurationRepository()
            .getConfiguration();

    if (data == null) return;

    rangeNameController.text =
        data["rangeName"] ?? "";

    rangeCodeController.text =
        data["rangeCode"] ?? "";

    officePrefixController.text =
        data["officePrefix"] ?? "";

    financialYearController.text =
        data["financialYear"] ?? "";

    officeAddressController.text =
        data["rangeOfficeAddress"] ?? "";

    divisionController.text =
        data["division"] ?? "";

    subDivisionController.text =
        data["subDivision"] ?? "";

    setState(() {});
  }

  Widget field(
      String title,
      TextEditingController controller) {

    return Padding(

      padding: const EdgeInsets.only(bottom: 15),

      child: TextField(

        controller: controller,

        decoration: InputDecoration(

          labelText: title,

          border: const OutlineInputBorder(),

        ),

      ),

    );

  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title:
            const Text("Office Configuration"),

      ),

      body: Padding(

        padding: const EdgeInsets.all(20),

        child: ListView(

          children: [

            field(
                "Range Name",
                rangeNameController),

            field(
                "Range Code",
                rangeCodeController),

            field(
                "Office Prefix",
                officePrefixController),

            field(
                "Financial Year",
                financialYearController),

            field(
                "Range Office Address",
                officeAddressController),

            field(
                "Division",
                divisionController),

            field(
                "Sub Division",
                subDivisionController),

            const SizedBox(height: 20),

            SizedBox(

              height: 50,

              child: ElevatedButton(

                onPressed: () async {

                  await OfficeConfigurationRepository()
                      .saveConfiguration(

                    rangeName:
                        rangeNameController.text,

                    rangeCode:
                        rangeCodeController.text,

                    officePrefix:
                        officePrefixController.text,

                    financialYear:
                        financialYearController.text,

                    rangeOfficeAddress:
                        officeAddressController.text,

                    division:
                        divisionController.text,

                    subDivision:
                        subDivisionController.text,

                  );

                  if (!mounted) return;

                  ScaffoldMessenger.of(context)
                      .showSnackBar(

                    const SnackBar(

                      content: Text(
                          "Configuration Saved"),

                    ),

                  );

                },

                child: const Text(
                    "SAVE CONFIGURATION"),

              ),

            ),

          ],

        ),

      ),

    );

  }

}