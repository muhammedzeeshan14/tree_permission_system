import 'package:flutter/material.dart';

import '../../repositories/master_repository.dart';

class GenericMasterScreen extends StatefulWidget {

  final String masterType;

  final String title;

  const GenericMasterScreen({

    super.key,

    required this.masterType,

    required this.title,

  });

  @override
State<GenericMasterScreen> createState() =>
    _GenericMasterScreenState();
}

class _GenericMasterScreenState
    extends State<GenericMasterScreen> {

  List<Map<String, dynamic>> masters = [];

  @override
  void initState() {
    super.initState();
    loadData();
  }

  Future<void> loadData() async {

    masters = await MasterRepository()
        .getMasters(widget.masterType);

    if (mounted) {
      setState(() {});
    }

  }
Future<void> showMasterDialog({

  Map<String, dynamic>? item,

}) async {

  final valueController = TextEditingController(
    text: item?["value"] ?? "",
  );

  final codeController = TextEditingController(
    text: item?["code"] ?? "",
  );

  final remarksController = TextEditingController(
    text: item?["remarks"] ?? "",
  );

  final displayOrderController = TextEditingController(
    text: item?["displayOrder"]?.toString() ?? "1",
  );

  bool isActive =
      (item?["isActive"] ?? 1) == 1;

  await showDialog(

    context: context,

    builder: (dialogContext) {

      return StatefulBuilder(

        builder: (dialogContext, setDialogState) {

          return AlertDialog(

            title: Text(
              item == null
                  ? "Add ${widget.title}"
                  : "Edit ${widget.title}",
            ),

            content: SizedBox(

              width: 450,

              child: SingleChildScrollView(

                child: Column(

                  mainAxisSize: MainAxisSize.min,

                  children: [

                    TextField(
                      controller: valueController,
                      decoration: InputDecoration(
                        labelText: widget.title,
                      ),
                    ),

                    const SizedBox(height: 15),

                    TextField(
                      controller: codeController,
                      decoration: const InputDecoration(
                        labelText: "Code",
                      ),
                    ),

                    const SizedBox(height: 15),

                    TextField(
                      controller: remarksController,
                      decoration: const InputDecoration(
                        labelText: "Remarks",
                      ),
                      maxLines: 2,
                    ),

                    const SizedBox(height: 15),

                    TextField(
                      controller: displayOrderController,
                      keyboardType:
                          TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: "Display Order",
                      ),
                    ),

                    const SizedBox(height: 15),

                    SwitchListTile(

                      title: const Text("Active"),

                      value: isActive,

                      onChanged: (value) {

                        setDialogState(() {

                          isActive = value;

                        });

                      },

                    ),

                  ],

                ),

              ),

            ),

            actions: [

              TextButton(

                onPressed: () {

                  Navigator.pop(dialogContext);

                },

                child: const Text("Cancel"),

              ),

              ElevatedButton(

                onPressed: () async {

                  if (item == null) {

                    await MasterRepository().insert(

                      masterType: widget.masterType,

                      value: valueController.text,

                      code: codeController.text,

                      displayOrder:
                          int.tryParse(
                              displayOrderController.text) ??
                              1,

                      remarks:
                          remarksController.text,

                      isActive: isActive,

                    );

                  } else {

                    await MasterRepository().update(

                      id: item["id"],

                      value: valueController.text,

                      code: codeController.text,

                      displayOrder:
                          int.tryParse(
                              displayOrderController.text) ??
                              1,

                      remarks:
                          remarksController.text,

                      isActive: isActive,

                    );

                  }

                  Navigator.pop(dialogContext);

                  loadData();

                },

                child: const Text("Save"),

              ),

            ],

          );

        },

      );

    },

  );

}
  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title: Text(widget.title),

      ),

      body: masters.isEmpty

    ? const Center(

        child: Text(

          "No Records Found",

          style: TextStyle(

            fontSize: 18,

          ),

        ),

      )

    : ListView.builder(

        itemCount: masters.length,

        itemBuilder: (context, index) {

          final item = masters[index];

          return Card(

            margin: const EdgeInsets.symmetric(

              horizontal: 10,

              vertical: 5,

            ),

            child: ListTile(

              leading: CircleAvatar(

                child: Text("${index + 1}"),

              ),

              title: Text(

                item["value"] ?? "",

              ),

              subtitle: Text(

                item["code"] ?? "",

              ),

              trailing: Text(

                item["isActive"] == 1

                    ? "Active"

                    : "Inactive",

              ),
onTap: () {

  showMasterDialog(
    item: item,
  );

},
            ),

          );

        },

      ),
 floatingActionButton: FloatingActionButton(

  onPressed: () {

    showMasterDialog();

  },

  child: const Icon(Icons.add),

),

    );

  }

}