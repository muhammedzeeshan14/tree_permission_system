import 'package:flutter/material.dart';

import '../../models/application_model.dart';
import '../../repositories/application_repository.dart';
import '../../services/session_service.dart';
import '../../widgets/tpms_drawer.dart';

import 'wizard/bfo_wizard_controller.dart';
import '../../constants/workflow_status.dart';

class BFODashboardScreen extends StatefulWidget {

  const BFODashboardScreen({

    super.key,

  });

  @override
  State<BFODashboardScreen> createState() =>
      _BFODashboardScreenState();

}

class _BFODashboardScreenState
    extends State<BFODashboardScreen> {

  final ApplicationRepository repository =
      ApplicationRepository();

  List<ApplicationModel> applications = [];

  bool loading = true;

  @override
  void initState() {

    super.initState();

    loadApplications();

  }

  Future<void> loadApplications() async {

    applications =
        await repository.getApplicationsForBFO(

      SessionService.instance.userId!,

    );

    applications = applications.where(

  (e) =>

      e.status ==
          WorkflowStatus.pendingBFOInspection ||

      e.status ==
          WorkflowStatus.returnedToBFO,

).toList();

    if (mounted) {

      setState(() {

        loading = false;

      });

    }

  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

  drawer: const TPMSDrawer(),

      appBar: AppBar(

        centerTitle: true,

        title: const Text(

          "BFO Dashboard",

        ),

      ),

      body: loading

          ? const Center(

              child:

                  CircularProgressIndicator(),

            )

          : applications.isEmpty

              ? const Center(

                  child: Text(

                    "No Applications Assigned",

                    style: TextStyle(

                      fontSize: 18,

                      fontWeight:

                          FontWeight.bold,

                    ),

                  ),

                )

              : ListView.builder(

                  padding:
                      const EdgeInsets.all(12),

                  itemCount:
                      applications.length,

                  itemBuilder:

                      (context, index) {

                    final app =
                        applications[index];
                                            return Card(

                      elevation: 4,

                      margin: const EdgeInsets.only(

                        bottom: 15,

                      ),

                      shape: RoundedRectangleBorder(

                        borderRadius:

                            BorderRadius.circular(12),

                      ),

                      child: Padding(

                        padding:

                            const EdgeInsets.all(16),

                        child: Column(

                          crossAxisAlignment:
                              CrossAxisAlignment.start,

                          children: [

                            Text(

                              app.officeNumber,

                              style: const TextStyle(

                                fontSize: 18,

                                fontWeight:

                                    FontWeight.bold,

                              ),

                            ),

                            const Divider(),

                            Text(

                              "Applicant : ${app.applicantName}",

                            ),

                            const SizedBox(height: 5),

                            Text(

                              "Address : ${app.applicantAddress}",

                            ),

                            const SizedBox(height: 5),

                            Text(

                              "Section : ${app.section}",

                            ),

                            const SizedBox(height: 5),

                            Text(

                              "Beat : ${app.beat}",

                            ),

                            const SizedBox(height: 5),

                            Text(

                              "Application Type : ${app.applicationType}",

                            ),

                            const SizedBox(height: 5),

                            Text(

                              "Status : ${app.status}",

                            ),

                            if (app.status ==
    WorkflowStatus.returnedToBFO)

  const Padding(

    padding: EdgeInsets.only(top: 8),

    child: Chip(

      label: Text("Returned for Re-inspection"),

      backgroundColor: Colors.orange,

    ),

  ),

                            const SizedBox(height: 20),

                            SizedBox(

                              width: double.infinity,

                              height: 50,

                              child: ElevatedButton.icon(

                                icon: const Icon(

                                  Icons.forest,

                                ),

                                label: Text(

  app.status ==
          WorkflowStatus.returnedToBFO

      ? "RE-INSPECT"

      : app.inspectionStarted

            ? "CONTINUE INSPECTION"

            : "START INSPECTION",

),

                                onPressed: () async {

                                  if (!app.inspectionStarted) {

                                    app.inspectionStarted = true;

                                    await repository
                                        .updateApplication(

                                      app,

                                    );

                                  }

                                  await Navigator.push(

                                    context,

                                    MaterialPageRoute(

                                      builder: (_) =>

                                          BFOWizardController(

                                        application: app,

                                      ),

                                    ),

                                  );

                                  await loadApplications();

                                },

                              ),

                            ),

                          ],

                        ),

                      ),

                    );
                                      },

                ),

    );

  }

}