import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';

import '../../../database/database_helper.dart';
import '../../../models/application_model.dart';
import '../../../models/tree_model.dart';
import '../../../repositories/application_repository.dart';
import '../../../repositories/tree_repository.dart';
import '../../../widgets/application_header_card.dart';
import '../../../widgets/tpms_app_bar.dart';
import '../../../widgets/wizard_progress_card.dart';
import '../../../services/tree_numbering_service.dart';

class AddEditTreeScreen extends StatefulWidget {
  final TreeModel tree;
  final bool isEdit;

  const AddEditTreeScreen({
    super.key,
    required this.tree,
    required this.isEdit,
  });

  @override
  State<AddEditTreeScreen> createState() =>
      _AddEditTreeScreenState();
}

class _AddEditTreeScreenState
    extends State<AddEditTreeScreen> {

  //----------------------------------------------------------
  // Repositories
  //----------------------------------------------------------

  final TreeRepository _treeRepository =
      TreeRepository();

  final ApplicationRepository
      _applicationRepository =
      ApplicationRepository();

  //----------------------------------------------------------
  // Database
  //----------------------------------------------------------

  final DatabaseHelper _dbHelper =
      DatabaseHelper.instance;

  //----------------------------------------------------------
  // Form
  //----------------------------------------------------------

  final _formKey =
      GlobalKey<FormState>();

  //----------------------------------------------------------
  // Screen State
  //----------------------------------------------------------

  bool _loading = true;

  ApplicationModel? application;

  //----------------------------------------------------------
  // Masters
  //----------------------------------------------------------

  List<Map<String, dynamic>>
      speciesList = [];

  List<Map<String,dynamic>> recommendationTypeList=[];

List<Map<String,dynamic>> recommendationReasonList=[];

  //----------------------------------------------------------
  // Selected Values
  //----------------------------------------------------------

  int? selectedSpeciesId;

  int? selectedRecommendationTypeId;

String selectedRecommendationCode = "";

  List<int> selectedReasons = [];
  bool notFitForTimber = false;

  //----------------------------------------------------------
  // Controllers
  //----------------------------------------------------------

  final gbhController =
      TextEditingController();

  final heightController =
      TextEditingController();

  final branchesController =
      TextEditingController();

      final twigsController =
    TextEditingController();

  final firewoodController =
      TextEditingController();

  final remarksController =
      TextEditingController();

  //----------------------------------------------------------
  // Init
  //----------------------------------------------------------

  @override
  void initState() {

    super.initState();

    _initialize();

  }

  //----------------------------------------------------------
  // Dispose
  //----------------------------------------------------------

  @override
  void dispose() {

    gbhController.dispose();

    heightController.dispose();

    branchesController.dispose();

    twigsController.dispose();

    firewoodController.dispose();

    remarksController.dispose();

    super.dispose();

  }

  //----------------------------------------------------------
  // Initialize Screen
  //----------------------------------------------------------

  Future<void> _initialize() async {
  try {
    await _loadApplication();
    await _loadSpecies();
    await _loadRecommendationTypes();
    await _loadTree();
  } catch (e, s) {
    debugPrint("AddEditTreeScreen initialization failed");
    debugPrint(e.toString());
    debugPrint(s.toString());
  } finally {
    if (mounted) {
      setState(() {
        _loading = false;
      });
    }
  }
}

  //----------------------------------------------------------
  // Load Application
  //----------------------------------------------------------

  Future<void> _loadApplication() async {

    application =
        await _applicationRepository.getById(
      widget.tree.applicationId,
    );

  }

  //----------------------------------------------------------
  // Load Species
  //----------------------------------------------------------

  Future<void> _loadSpecies() async {

  final Database db =
      await _dbHelper.database;

  speciesList = await db.query(

    "master_data",

    where: "masterType=? AND isActive=1",

    whereArgs: const ["Species"],

    orderBy: "displayOrder",

  );

}

//----------------------------------------------------------
// Load Recommendation Types
//----------------------------------------------------------

Future<void> _loadRecommendationTypes() async {

  final Database db = await _dbHelper.database;

  recommendationTypeList = await db.query(

    "master_data",

    where: "masterType=? AND isActive=1",

    whereArgs: const [

      "Recommendation Type",

    ],

    orderBy: "displayOrder",

  );

}

  //----------------------------------------------------------
// Load Recommendation Reasons
//----------------------------------------------------------

Future<void> _loadRecommendationReasons() async {

  recommendationReasonList.clear();
  selectedReasons.clear();

  if (selectedRecommendationCode.isEmpty) {

    return;

  }

  final Database db = await _dbHelper.database;

  recommendationReasonList = await db.query(

    "master_data",

    where:

        "masterType=? AND parentCode=? AND isActive=1",

    whereArgs: [

      "Recommendation Reason",

      selectedRecommendationCode,

    ],

    orderBy: "displayOrder",

  );

}

//----------------------------------------------------------
// Recommendation Changed
//----------------------------------------------------------

Future<void> _onRecommendationTypeChanged(
    int recommendationTypeId,
) async {

  final item = recommendationTypeList.firstWhere(
    (e) => e["id"] == recommendationTypeId,
  );

  final newCode = item["code"].toString();

  final Database db = await _dbHelper.database;

  final reasons = await db.query(
    "master_data",
    where:
        "masterType=? AND parentCode=? AND isActive=1",
    whereArgs: [
      "Recommendation Reason",
      newCode,
    ],
    orderBy: "displayOrder",
  );

  if (!mounted) return;

  setState(() {

    //------------------------------------------------
    // Recommendation
    //------------------------------------------------

    selectedRecommendationTypeId =
        recommendationTypeId;

    selectedRecommendationCode =
        newCode;

    //------------------------------------------------
    // New reason list
    //------------------------------------------------

    recommendationReasonList = reasons;

    //------------------------------------------------
    // Clear selected reasons
    //------------------------------------------------

    selectedReasons.clear();

    //------------------------------------------------
    // Clear measurements
    //------------------------------------------------

    gbhController.clear();

    heightController.clear();

    branchesController.clear();

    twigsController.clear();

    firewoodController.clear();

  });

}

  //----------------------------------------------------------
  // Load Existing Tree
  //----------------------------------------------------------

  Future<void> _loadTree() async {

    final tree = widget.tree;

    selectedSpeciesId =
    tree.speciesId == 0 ? null : tree.speciesId;

    selectedRecommendationTypeId =
    tree.recommendationTypeId;

selectedRecommendationCode = "";

recommendationReasonList.clear();

if (selectedRecommendationTypeId != null) {

  final item = recommendationTypeList.firstWhere(

    (e) =>

        e["id"] == selectedRecommendationTypeId,

    orElse: () => {},

  );

  if (item.isNotEmpty) {

    selectedRecommendationCode =
        item["code"].toString();

  }

}

    selectedReasons =
        List<int>.from(
            tree.recommendationReasonIds);

    gbhController.text =
        tree.gbh?.toString() ?? "";

    heightController.text =
        tree.height?.toString() ?? "";

notFitForTimber =
    tree.notFitForTimber;

    branchesController.text =
        tree.numberOfBranches
                ?.toString() ??
            "";

            twigsController.text =
    tree.numberOfTwigs
            ?.toString() ??
        "";

    firewoodController.text =
        tree.firewood.toString();

    remarksController.text =
        tree.remarks;

  }
    //----------------------------------------------------------
  // Validate
  //----------------------------------------------------------

  bool _validate() {

    if (!_formKey.currentState!.validate()) {
      return false;
    }

    if (selectedSpeciesId == null) {

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Please select species."),
        ),
      );

      return false;
    }

   if (selectedRecommendationTypeId != null &&
    selectedReasons.isEmpty) {

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            "Select at least one recommendation reason.",
          ),
        ),
      );

      return false;
    }

    return true;
  }

  //----------------------------------------------------------
  // Save Tree
  //----------------------------------------------------------

  Future<int> _saveCurrentTree() async {

  if (!_validate()) return -1;

  setState(() {
    _loading = true;
  });

  final tree = TreeModel(
    id: widget.tree.id,
    applicationId: widget.tree.applicationId,
    treeNumber: widget.tree.treeNumber,
    baseTreeNumber: widget.tree.baseTreeNumber,
    stemType: widget.tree.stemType,
    stemLetter: widget.tree.stemLetter,
    stemSequence: widget.tree.stemSequence,
    isLastStem: widget.tree.isLastStem,
    speciesId: selectedSpeciesId!,
    recommendationTypeId:
    selectedRecommendationTypeId!,
    gbh: gbhController.text.trim().isEmpty
        ? null
        : double.parse(gbhController.text.trim()),
    height: heightController.text.trim().isEmpty
        ? null
        : double.parse(heightController.text.trim()),
        notFitForTimber:
    notFitForTimber,
    numberOfBranches:
    branchesController.text.trim().isEmpty
        ? null
        : int.parse(
            branchesController.text.trim()),

numberOfTwigs:
    twigsController.text.trim().isEmpty
        ? null
        : int.parse(
            twigsController.text.trim()),
    firewood: firewoodController.text.trim().isEmpty
        ? 0
        : double.parse(firewoodController.text.trim()),
    
    recommendationReasonIds: List<int>.from(selectedReasons),
    remarks: remarksController.text.trim(),
  );

  if (widget.isEdit) {

    await _treeRepository.updateTree(tree);

    return tree.id!;

  } else {

    return await _treeRepository.insertTree(tree);

  }

}

  Future<void> _updateTree() async {

  await _saveCurrentTree();

  if (!mounted) return;

  Navigator.pop(context, true);

}

Future<void> _saveAndFinishTree() async {

  final insertedId = await _saveCurrentTree();

  if (insertedId == -1) return;

  if (!mounted) return;

  Navigator.pop(context, true);

}

Future<void> _saveAndNextStem() async {

  final insertedId = await _saveCurrentTree();

if (insertedId == -1) return;

final currentTree = TreeModel(
    id: widget.tree.id ?? insertedId,
  applicationId: widget.tree.applicationId,
  treeNumber: widget.tree.treeNumber,
  baseTreeNumber: widget.tree.baseTreeNumber,
  stemType: widget.tree.stemType,
  stemLetter: widget.tree.stemLetter,
  stemSequence: widget.tree.stemSequence,
  isLastStem: false,
  speciesId: selectedSpeciesId!,
  recommendationTypeId:
    selectedRecommendationTypeId!,
  gbh: gbhController.text.trim().isEmpty
      ? null
      : double.parse(gbhController.text.trim()),
  height: heightController.text.trim().isEmpty
      ? null
      : double.parse(heightController.text.trim()),
      notFitForTimber:
    notFitForTimber,
  numberOfBranches:
    branchesController.text.trim().isEmpty
        ? null
        : int.parse(
            branchesController.text.trim()),

numberOfTwigs:
    twigsController.text.trim().isEmpty
        ? null
        : int.parse(
            twigsController.text.trim()),
  firewood: firewoodController.text.trim().isEmpty
      ? 0
      : double.parse(firewoodController.text.trim()),
 
  recommendationReasonIds: List<int>.from(selectedReasons),
  remarks: remarksController.text.trim(),
);

await _treeRepository.updateTree(currentTree);

  final next =
      await TreeNumberingService().nextStem(

    widget.tree.applicationId,

    widget.tree.baseTreeNumber,

    widget.tree.stemLetter,

  );

  if (!mounted) return;

  if (!mounted) return;

Navigator.pop(
  context,
  TreeModel(
    applicationId: widget.tree.applicationId,
    treeNumber: next["treeNumber"],
    baseTreeNumber: next["baseTreeNumber"],
    stemType: "Multiple",
    stemLetter: next["stemLetter"],
    stemSequence: widget.tree.stemSequence + 1,
    isLastStem: true,
    speciesId: selectedSpeciesId!,
    recommendationTypeId:
    selectedRecommendationTypeId!,
    gbh: null,
    height: null,
    notFitForTimber: false,
    numberOfBranches: null,
    firewood: 0,
   
    recommendationReasonIds: List<int>.from(selectedReasons),
    remarks: "",
  ),
);

}

  //----------------------------------------------------------
  // Species Dropdown
  //----------------------------------------------------------

  Widget _speciesDropdown() {

    if (widget.tree.stemType == "Multiple" &&
    widget.tree.stemSequence > 1) {

  final species = speciesList.firstWhere(
    (e) => e["id"] == selectedSpeciesId,
  );

  return TextFormField(
    initialValue:
        species["value"].toString(),
    enabled: false,
    decoration: const InputDecoration(
      labelText: "Species",
      border: OutlineInputBorder(),
    ),
  );
}

    return DropdownButtonFormField<int>(

      value: speciesList.any(
        (e) => e["id"] == selectedSpeciesId)
    ? selectedSpeciesId
    : null,

      decoration: const InputDecoration(

        labelText: "Species",

        border: OutlineInputBorder(),

      ),

      items: speciesList.map((species) {

        return DropdownMenuItem<int>(

          value: species["id"] as int,

          child: Text(
            species["value"].toString(),
          ),

        );

      }).toList(),

      onChanged: (value) {

        setState(() {

          selectedSpeciesId = value;

        });

      },

      validator: (_) {

        if (selectedSpeciesId == null) {

          return "Select Species";

        }

        return null;

      },

    );

  }

//----------------------------------------------------------
// Recommendation Type
//----------------------------------------------------------

Widget _recommendationTypeDropdown() {

  return DropdownButtonFormField<int>(

    value: recommendationTypeList.any(
      (e) => e["id"] == selectedRecommendationTypeId,
    )
        ? selectedRecommendationTypeId
        : null,

    decoration: const InputDecoration(

      labelText: "Recommendation",

      border: OutlineInputBorder(),

    ),

    items: recommendationTypeList.map((item) {

      return DropdownMenuItem<int>(

        value: item["id"],

        child: Text(item["value"]),

      );

    }).toList(),

    onChanged: (value) async {

  if (value == null) return;

  await _onRecommendationTypeChanged(value);

},


    validator: (_) {

      if (selectedRecommendationTypeId == null) {

        return "Select Recommendation";

      }

      return null;

    },

  );

}

  //----------------------------------------------------------
  // Recommendation Reasons
  //----------------------------------------------------------

  Widget _recommendationReasons() {

  if (selectedRecommendationTypeId == null ||
    recommendationReasonList.isEmpty) {

  return const SizedBox();

}

  return Card(

    child: Padding(

      padding: const EdgeInsets.all(12),

      child: Column(

        crossAxisAlignment:
            CrossAxisAlignment.start,

        children: [

          const Text(

            "Recommendation Reasons",

            style: TextStyle(

              fontWeight: FontWeight.bold,

              fontSize: 16,

            ),

          ),

          const Divider(),

          ...recommendationReasonList.map((reason) {

            final id = reason["id"] as int;

            return CheckboxListTile(

              dense: true,

              value:
                  selectedReasons.contains(id),

              title: Text(reason["value"]),

              onChanged: (checked) {

                setState(() {

                  if (checked == true) {

                    selectedReasons.add(id);

                  } else {

                    selectedReasons.remove(id);

                  }

                });

              },

            );

          }),

        ],

      ),

    ),

  );

}

    //----------------------------------------------------------
  // Tree Information Card
  //----------------------------------------------------------

  Widget _treeInformationCard() {

    return Card(

      child: Padding(

        padding: const EdgeInsets.all(16),

        child: Column(

          crossAxisAlignment:
              CrossAxisAlignment.start,

          children: [

            const Text(

              "Tree Information",

              style: TextStyle(

                fontSize: 16,

                fontWeight: FontWeight.bold,

              ),

            ),

            const Divider(),

            _infoRow(
  "Tree Number",
  widget.tree.treeNumber.toString(),
),

            _infoRow(
              "Stem Type",
              widget.tree.stemType,
            ),

            _infoRow(
              "Stem Letter",
              widget.tree.stemLetter.isEmpty
                  ? "-"
                  : widget.tree.stemLetter,
            ),

            _infoRow(
              "Base Tree",
              widget.tree.baseTreeNumber
                  .toString(),
            ),

          ],

        ),

      ),

    );

  }

  //----------------------------------------------------------
  // Information Row
  //----------------------------------------------------------

  Widget _infoRow(
    String title,
    String value,
  ) {

    return Padding(

      padding: const EdgeInsets.symmetric(
        vertical: 5,
      ),

      child: Row(

        children: [

          SizedBox(

            width: 120,

            child: Text(

              title,

              style: const TextStyle(
                fontWeight:
                    FontWeight.w600,
              ),

            ),

          ),

          Expanded(
            child: Text(value),
          ),

        ],

      ),

    );

  }

  //----------------------------------------------------------
  // Measurements Card
  //----------------------------------------------------------

  Widget _measurementCard() {

  if (selectedRecommendationCode == "NR") {
    return const SizedBox();
  }

  return Card(

    child: Padding(

      padding: const EdgeInsets.all(16),

      child: Column(

        crossAxisAlignment:
            CrossAxisAlignment.start,

        children: [

          const Text(

            "Measurements",

            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),

          ),

          const Divider(),

          if (selectedRecommendationCode == "FULL") ...[

            Column(
  children: [

    Row(
      children: [

        Expanded(
          child: _numberField(
            controller: gbhController,
            label: "GBH (cm)",
          ),
        ),

        const SizedBox(width: 12),

        Expanded(
          child: _numberField(
            controller: heightController,
            label: "Height (m)",
          ),
        ),

      ],
    ),

    const SizedBox(height: 12),

CheckboxListTile(

  contentPadding: EdgeInsets.zero,

  value: notFitForTimber,

  title: const Text(

    "Not Fit For Timber",

  ),

  onChanged: (value) {

    setState(() {

      notFitForTimber = value ?? false;

    });

  },

),

    const SizedBox(height: 16),

    _numberField(
      controller: firewoodController,
      label: "Firewood (Tonnes)",
    ),

  ],
),

            const SizedBox(height: 16),

          ],

          if (selectedRecommendationCode == "BRANCH") ...[

  Row(
    children: [

      Expanded(
        child: _numberField(
          controller: branchesController,
          label: "Branches",
          integerOnly: true,
        ),
      ),

      const SizedBox(width: 12),

      Expanded(
        child: _numberField(
          controller: firewoodController,
          label: "Firewood",
        ),
      ),

    ],
  ),

  const SizedBox(height: 16),

],

if (selectedRecommendationCode == "TWIG") ...[

  Row(
    children: [

      Expanded(
        child: _numberField(
          controller: twigsController,
          label: "Twigs",
          integerOnly: true,
        ),
      ),

      const SizedBox(width: 12),

      Expanded(
        child: _numberField(
          controller: firewoodController,
          label: "Firewood",
        ),
      ),

    ],
  ),

  const SizedBox(height: 16),

],

if (selectedRecommendationCode == "TOP") ...[

  _numberField(
    controller: firewoodController,
    label: "Firewood",
  ),

],

      ],
    ),
  ),
);
}

  //----------------------------------------------------------
  // Remarks
  //----------------------------------------------------------

  Widget _remarksField() {

    return TextFormField(

      controller:
          remarksController,

      maxLines: 4,

      decoration:
          const InputDecoration(

        labelText: "Remarks",

        border:
            OutlineInputBorder(),

      ),

    );

  }

  //----------------------------------------------------------
  // Number Field
  //----------------------------------------------------------

  Widget _numberField({

    required TextEditingController
        controller,

    required String label,

    bool integerOnly = false,

  }) {

    return TextFormField(

      controller: controller,

      keyboardType:
          const TextInputType.numberWithOptions(

        decimal: true,

      ),

      decoration: InputDecoration(

        labelText: label,

        border:
            const OutlineInputBorder(),

      ),

      validator: (value) {

        if (value == null ||
            value.trim().isEmpty) {

          return null;

        }

        if (integerOnly) {

          if (int.tryParse(value) ==
              null) {

            return "Invalid number";

          }

        } else {

          if (double.tryParse(value) ==
              null) {

            return "Invalid number";

          }

        }

        return null;

      },

    );

  }
    //----------------------------------------------------------
  // BUILD
  //----------------------------------------------------------

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: const TPMSAppBar(
        title: "Tree Inspection",
      ),

      body: _loading

          ? const Center(
              child: CircularProgressIndicator(),
            )

          : application == null

              ? const Center(
                  child: Text(
                    "Application not found.",
                  ),
                )

              : Form(

                  key: _formKey,

                  child: Column(

                    children: [

                      //------------------------------------------------
                      // Header
                      //------------------------------------------------

                      ApplicationHeaderCard(
                        application: application!,
                      ),

                      //------------------------------------------------
                      // Wizard
                      //------------------------------------------------

                      const WizardProgressCard(
                        currentStep: 5,
                        totalSteps: 8,
                        title: "Tree Inspection",
                      ),

                      //------------------------------------------------
                      // Form
                      //------------------------------------------------

                      Expanded(

                        child: SingleChildScrollView(

                          padding:
                              const EdgeInsets.all(16),

                          child: Column(

                            crossAxisAlignment:
                                CrossAxisAlignment.stretch,

                            children: [

                              _treeInformationCard(),

                              const SizedBox(height: 16),

                              Card(

                                child: Padding(

                                  padding:
                                      const EdgeInsets.all(16),

                                  child: Column(

                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,

                                    children: [

                                      const Text(

                                        "Inspection",

                                        style: TextStyle(

                                          fontWeight:
                                              FontWeight.bold,

                                          fontSize: 16,

                                        ),

                                      ),

                                      const Divider(),

                                      Row(
  children: [

    Expanded(
      child: _speciesDropdown(),
    ),

    const SizedBox(width: 16),

    Expanded(
      child: _recommendationTypeDropdown(),
    ),

  ],
),

                                    ],

                                  ),

                                ),

                              ),

                              const SizedBox(height: 16),

                              _recommendationReasons(),

                              if (selectedRecommendationCode == "NR")
  const SizedBox(height: 16),

                              _measurementCard(),

                              const SizedBox(height: 16),

                              Card(

                                child: Padding(

                                  padding:
                                      const EdgeInsets.all(16),

                                  child: Column(

                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,

                                    children: [

                                      const Text(

                                        "Remarks",

                                        style: TextStyle(

                                          fontWeight:
                                              FontWeight.bold,

                                          fontSize: 16,

                                        ),

                                      ),

                                      const Divider(),

                                      _remarksField(),

                                    ],

                                  ),

                                ),

                              ),

                              const SizedBox(height: 24),
                              
                              //------------------------------------------------
// Buttons
//------------------------------------------------

if (widget.isEdit)

  Row(

    children: [

      Expanded(

        child: OutlinedButton.icon(

          icon: const Icon(Icons.close),

          label: const Text("Cancel"),

          onPressed: () {

            Navigator.pop(context);

          },

        ),

      ),

      const SizedBox(width: 16),

      Expanded(

        child: ElevatedButton.icon(

          icon: const Icon(Icons.save),

          label: const Text("Update Tree"),

         onPressed: () {

  _updateTree();

},

        ),

      ),

    ],

  )

else if (widget.tree.stemType == "Single")

  Row(

    children: [

      Expanded(

        child: OutlinedButton.icon(

          icon: const Icon(Icons.close),

          label: const Text("Cancel"),

          onPressed: () {

            Navigator.pop(context);

          },

        ),

      ),

      const SizedBox(width: 16),

      Expanded(

        child: ElevatedButton.icon(

          icon: const Icon(Icons.save),

          label: const Text("Save Tree"),

          onPressed: () {

            _saveAndFinishTree();

          },

        ),

      ),

    ],

  )

else

  Row(

    children: [

      Expanded(

        child: OutlinedButton(

          onPressed: () {

            Navigator.pop(context);

          },

          child: const Text(
            "Cancel",
          ),

        ),

      ),

      const SizedBox(width: 8),

      Expanded(

        child: ElevatedButton(

          onPressed: () {

  _saveAndNextStem();

},

          child: const Text(
            "Next Stem",
          ),

        ),

      ),

      const SizedBox(width: 8),

      Expanded(

        child: ElevatedButton(

          onPressed: () {

  _saveAndFinishTree();

},

          child: const Text(
            "Finish Tree",
          ),

        ),

      ),

    ],

  ),

                              const SizedBox(height: 24),

                            ],

                          ),

                        ),

                      ),

                    ],

                  ),

                ),

    );

  }
    //----------------------------------------------------------
  // Reset Form
  //----------------------------------------------------------

  void _resetForm() {

    setState(() {

      selectedSpeciesId = null;

      selectedRecommendationTypeId = null;

selectedRecommendationCode = "";

      selectedReasons.clear();

      gbhController.clear();

      heightController.clear();

      branchesController.clear();

      firewoodController.clear();

      remarksController.clear();

    });

  }

  //----------------------------------------------------------
  // Clear Recommendation Reasons
  //----------------------------------------------------------

  void _clearRecommendationReasons() {

    setState(() {

      selectedReasons.clear();

    });

  }

  //----------------------------------------------------------
  // Toggle Recommendation Reason
  //----------------------------------------------------------

  void _toggleRecommendationReason(int id) {

    setState(() {

      if (selectedReasons.contains(id)) {

        selectedReasons.remove(id);

      } else {

        selectedReasons.add(id);

      }

    });

  }

  //----------------------------------------------------------
  // Selected Reason Count
  //----------------------------------------------------------

  int get _selectedReasonCount {

    return selectedReasons.length;

  }

  //----------------------------------------------------------
  // Parse Double
  //----------------------------------------------------------

  double? _parseDouble(String value) {

    if (value.trim().isEmpty) {

      return null;

    }

    return double.tryParse(value.trim());

  }

  //----------------------------------------------------------
  // Parse Integer
  //----------------------------------------------------------

  int? _parseInt(String value) {

    if (value.trim().isEmpty) {

      return null;

    }

    return int.tryParse(value.trim());

  }

  //----------------------------------------------------------
  // Firewood Value
  //----------------------------------------------------------

  double get _firewoodValue {

    return _parseDouble(
            firewoodController.text) ??
        0;

  }

  //----------------------------------------------------------
  // GBH Value
  //----------------------------------------------------------

  double? get _gbhValue {

    return _parseDouble(
        gbhController.text);

  }

  //----------------------------------------------------------
  // Height Value
  //----------------------------------------------------------

  double? get _heightValue {

    return _parseDouble(
        heightController.text);

  }

  //----------------------------------------------------------
  // Branch Count
  //----------------------------------------------------------

  int? get _branchCount {

    return _parseInt(
        branchesController.text);

  }

  //----------------------------------------------------------
  // Has Recommendation Reasons
  //----------------------------------------------------------

  bool get _hasReasons {

    return selectedReasons.isNotEmpty;

  }

  }