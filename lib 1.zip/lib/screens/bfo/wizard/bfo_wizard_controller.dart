import 'package:flutter/material.dart';

import '../../../models/application_model.dart';

import 'application_details_step.dart';
import 'inspection_decision_step.dart';
import 'application_type_step.dart';
import './gps_step.dart';
import 'tree_step.dart';
import 'photo_step.dart';
import 'document_step.dart';
import 'inspection_summary_step.dart';
import 'preview_submit_step.dart';
import '../../../repositories/inspection_defer_reason_repository.dart';
import 'mahazar_step.dart';
import 'revenue_opinion_step.dart';

class BFOWizardController extends StatefulWidget {

  final ApplicationModel application;

  const BFOWizardController({
    super.key,
    required this.application,
  });

  @override
  State<BFOWizardController> createState() =>
      _BFOWizardControllerState();
}

class _BFOWizardControllerState
    extends State<BFOWizardController> {

      final InspectionDeferredReasonRepository deferredRepository =
    InspectionDeferredReasonRepository();

  int currentStep = 0;
  final int totalSteps = 11;

  void nextStep() {

  int next = currentStep + 1;

  // --------------------------------------------------
  // Skip Revenue Opinion
  // except Private Land & Sandal Private
  // --------------------------------------------------

  if (next == 7 &&
    widget.application.applicationType != "PL" &&
    widget.application.applicationType != "SPL") {

  next = 8;

}

  // --------------------------------------------------
  // Skip Mahazar for Tree Count
  // --------------------------------------------------

  if (next == 8 &&
      widget.application.permissionType == "Tree Count") {

    next = 9;

  }

  if (next >= totalSteps) {

    return;

  }

  setState(() {

    currentStep = next;

  });

}

void jumpToPreviewSubmit() {

  setState(() {

    currentStep = 10;

  });

}

  void previousStep() {

  // Preview screen after Deferred Inspection
  if (currentStep == 9 &&
      widget.application.inspectionDecision == "DEFERRED") {

    setState(() {
      currentStep = 1;
    });

    return;
  }

  if (currentStep == 0) {
    return;
  }

  setState(() {
    currentStep--;
  });

}

@override
void initState() {
  super.initState();
  loadDeferredReasons();
}

Future<void> loadDeferredReasons() async {
  if (widget.application.id == null) {
    return;
  }

  widget.application.deferredReasonIds =
      await deferredRepository.getReasonIds(
    widget.application.id!,
  );

  if (mounted) {
    setState(() {});
  }
}

  @override
  Widget build(BuildContext context) {

print(
  ">>> PermissionTypeId=${widget.application.permissionTypeId} "
  "PermissionType=${widget.application.permissionType}",
);

    switch(currentStep){

      case 0:

        return ApplicationDetailsStep(

          application: widget.application,

          onNext: nextStep,

        );

      case 1:

        return InspectionDecisionStep(

          application: widget.application,

          onNext: nextStep,

          onBack: previousStep,

          onDeferred: jumpToPreviewSubmit,

        );
        case 2:

return ApplicationTypeStep(

  application: widget.application,

  onBack: previousStep,

  onNext: nextStep,

);
case 3:

  return GPSStep(

    application: widget.application,

    onBack: previousStep,

    onNext: nextStep,

  );
case 4:

  return TreeStep(

    application: widget.application,

    onBack: previousStep,

    onNext: nextStep,

  );
  case 5:

  return PhotoStep(

    application: widget.application,

    onBack: previousStep,

    onNext: nextStep,

  );
  case 6:

  return DocumentStep(

    application: widget.application,

    onBack: previousStep,

    onNext: nextStep,

  );
 
case 7:

  return RevenueOpinionStep(

    application: widget.application,

    onBack: previousStep,

    onNext: nextStep,

  );

case 8:

  return MahazarStep(

    application: widget.application,

    onBack: previousStep,

    onNext: nextStep,

  );

case 9:

  return InspectionSummaryStep(

    application: widget.application,

    onBack: previousStep,

    onNext: nextStep,

  );

  case 10:

  return PreviewSubmitStep(

    application: widget.application,

    onBack: previousStep,

  );

      default:

        return const Scaffold(

          body: Center(

            child: Text(

              "Next Step Coming...",

              style: TextStyle(
                fontSize:22,
                fontWeight: FontWeight.bold,
              ),

            ),

          ),

        );

    }

  }

}