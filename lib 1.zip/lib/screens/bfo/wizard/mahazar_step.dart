import 'package:flutter/material.dart';

import '../../../models/application_model.dart';
import '../../../models/mahazar_model.dart';
import '../../../repositories/mahazar_repository.dart';

class MahazarStep extends StatefulWidget {

  final ApplicationModel application;

  final VoidCallback onNext;

  final VoidCallback onBack;

  const MahazarStep({

    super.key,

    required this.application,

    required this.onNext,

    required this.onBack,

  });

  @override
  State<MahazarStep> createState() =>
      _MahazarStepState();

}

class _MahazarStepState
    extends State<MahazarStep> {

  final repo = MahazarRepository();

  final northController =
      TextEditingController();

  final eastController =
      TextEditingController();

  final southController =
      TextEditingController();

  final westController =
      TextEditingController();

final startManualController =
    TextEditingController();

final endManualController =
    TextEditingController();

  DateTime? mahazarDate;

TimeOfDay? startTime;

TimeOfDay? endTime;

  @override
  void initState() {

    super.initState();

    load();

  }

  Future<void> load() async {

    final data =
        await repo.getByApplication(

      widget.application.id!,

    );

    if (data != null) {

      if (data.mahazarDate.isNotEmpty) {

        mahazarDate =
            DateTime.parse(

          data.mahazarDate,

        );

      }

      northController.text =
          data.northBoundary;

      eastController.text =
          data.eastBoundary;

      southController.text =
          data.southBoundary;

      westController.text =
          data.westBoundary;

startManualController.text =
    data.startTimeManual;

endManualController.text =
    data.endTimeManual;

if (data.startTime.isNotEmpty) {

  final parts =
      data.startTime.split(":");

  startTime = TimeOfDay(

    hour: int.parse(parts[0]),

    minute: int.parse(parts[1]),

  );

}

if (data.endTime.isNotEmpty) {

  final parts =
      data.endTime.split(":");

  endTime = TimeOfDay(

    hour: int.parse(parts[0]),

    minute: int.parse(parts[1]),

  );

}

      if (mounted) {

        setState(() {});

      }

    }

  }

  Future<void> pickDate() async {

    final selected =
        await showDatePicker(

      context: context,

      initialDate:
          mahazarDate ??
              DateTime.now(),

      firstDate: DateTime(2020),

      lastDate: DateTime(2100),

    );

    if (selected != null) {

      setState(() {

        mahazarDate = selected;

      });

    }

  }

Future<void> pickStartTime() async {

  final result =
      await showTimePicker(

    context: context,

    initialTime:

        startTime ??

        TimeOfDay.now(),

  );

  if (result != null) {

    setState(() {

      startTime = result;

    });

  }

}

Future<void> pickEndTime() async {

  final result =
      await showTimePicker(

    context: context,

    initialTime:

        endTime ??

        TimeOfDay.now(),

  );

  if (result != null) {

    setState(() {

      endTime = result;

    });

  }

}

  Future<void> save() async {

    await repo.save(

      MahazarModel(

        applicationId:
            widget.application.id!,

        mahazarDate:

            mahazarDate
                    ?.toIso8601String() ??
                "",

startTime:

    startTime == null

        ? ""

        : "${startTime!.hour}:${startTime!.minute}",

startTimeManual:

    startManualController.text.trim(),

endTime:

    endTime == null

        ? ""

        : "${endTime!.hour}:${endTime!.minute}",

endTimeManual:

    endManualController.text.trim(),

        northBoundary:
            northController.text.trim(),

        eastBoundary:
            eastController.text.trim(),

        southBoundary:
            southController.text.trim(),

        westBoundary:
            westController.text.trim(),

      ),

    );

    widget.onNext();

  }

  Widget field(

    String title,

    TextEditingController controller,

  ) {

    return Padding(

      padding:
          const EdgeInsets.only(

        bottom: 16,

      ),

      child: TextField(

        controller: controller,

        minLines: 2,

        maxLines: 3,

        decoration: InputDecoration(

          labelText: title,

          border:
              const OutlineInputBorder(),

        ),

      ),

    );

  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title:
            const Text("Mahazar Details"),

      ),

      body: Padding(

        padding:
            const EdgeInsets.all(16),

        child: Column(

          children: [

            Card(

              child: ListTile(

                title: const Text(

                  "Mahazar Date",

                ),

                subtitle: Text(

                  mahazarDate == null

                      ? "Select Date"

                      : "${mahazarDate!.day}-${mahazarDate!.month}-${mahazarDate!.year}",

                ),

                trailing: const Icon(

                  Icons.calendar_month,

                ),

                onTap: pickDate,

              ),

            ),

            const SizedBox(height: 16),

Card(

  child: Padding(

    padding: const EdgeInsets.all(16),

    child: Column(

      children: [

        Row(

          children: [

            Expanded(

              flex: 2,

              child: ListTile(

                title: const Text(

                  "Starting Time",

                ),

                subtitle: Text(

                  startTime == null

                      ? "Select"

                      : startTime!
                          .format(context),

                ),

                trailing: const Icon(

                  Icons.access_time,

                ),

                onTap: pickStartTime,

              ),

            ),

            const SizedBox(width: 10),

            Expanded(

              flex: 2,

              child: TextField(

                controller:
                    startManualController,

                decoration:
                    const InputDecoration(

                  labelText:
                      "Manual Entry",

                  border:
                      OutlineInputBorder(),

                ),

              ),

            ),

          ],

        ),

        const SizedBox(height: 15),

        Row(

          children: [

            Expanded(

              flex: 2,

              child: ListTile(

                title: const Text(

                  "Ending Time",

                ),

                subtitle: Text(

                  endTime == null

                      ? "Select"

                      : endTime!
                          .format(context),

                ),

                trailing: const Icon(

                  Icons.access_time,

                ),

                onTap: pickEndTime,

              ),

            ),

            const SizedBox(width: 10),

            Expanded(

              flex: 2,

              child: TextField(

                controller:
                    endManualController,

                decoration:
                    const InputDecoration(

                  labelText:
                      "Manual Entry",

                  border:
                      OutlineInputBorder(),

                ),

              ),

            ),

          ],

        ),

      ],

    ),

  ),

),

const SizedBox(height: 16),

            Expanded(

              child:
                  SingleChildScrollView(

                child: Column(

                  children: [

                    field(
                      "North",
                      northController,
                    ),

                    field(
                      "East",
                      eastController,
                    ),

                    field(
                      "South",
                      southController,
                    ),

                    field(
                      "West",
                      westController,
                    ),

                  ],

                ),

              ),

            ),

            Row(

              children: [

                Expanded(

                  child: ElevatedButton(

                    onPressed:
                        widget.onBack,

                    child:
                        const Text("BACK"),

                  ),

                ),

                const SizedBox(width: 15),

                Expanded(

                  child: ElevatedButton(

                    onPressed: save,

                    child: const Text(

                      "SAVE & CONTINUE",

                    ),

                  ),

                ),

              ],

            ),

          ],

        ),

      ),

    );

  }

  @override
  void dispose() {

    northController.dispose();

    eastController.dispose();

    southController.dispose();

    westController.dispose();

    startManualController.dispose();

endManualController.dispose();
    
    super.dispose();

  }

}