import 'package:flutter/material.dart';

import '../../models/application_model.dart';
import '../../constants/history_actions.dart';
import '../../constants/workflow_status.dart';
import '../../repositories/application_repository.dart';
import '../../repositories/history_repository.dart';
import '../../services/session_service.dart';

class RFODecisionScreen extends StatefulWidget {

  final ApplicationModel application;

  const RFODecisionScreen({

    super.key,

    required this.application,

  });

  @override
  State<RFODecisionScreen> createState() =>
      _RFODecisionScreenState();

}

class _RFODecisionScreenState
    extends State<RFODecisionScreen> {

  final PageController pageController =
      PageController();

  int currentPage = 0;

  final remarksController =
      TextEditingController();
final ApplicationRepository applicationRepository =
    ApplicationRepository();

final HistoryRepository historyRepository =
    HistoryRepository();
  @override
  void initState() {

    super.initState();

    remarksController.text =
        widget.application.rfoOverallRemarks;

  }

  @override
  void dispose() {

    remarksController.dispose();

    pageController.dispose();

    super.dispose();

  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        centerTitle: true,

        title: const Text(

          "RFO Final Decision",

        ),

      ),

      body: Column(

        children: [

          Container(

            width: double.infinity,

            padding:
                const EdgeInsets.all(16),

            color: Colors.green.shade50,

            child: Column(

              crossAxisAlignment:
                  CrossAxisAlignment.start,

              children: [

                Text(

                  widget.application.officeNumber,

                  style: const TextStyle(

                    fontWeight:
                        FontWeight.bold,

                    fontSize: 20,

                  ),

                ),

                const SizedBox(height: 6),

                Text(
                  "Applicant : ${widget.application.applicantName}",
                ),

                Text(
                  "Section : ${widget.application.section}",
                ),

                Text(
                  "Beat : ${widget.application.beat}",
                ),

                Text(
                  "Application Type : ${widget.application.applicationType}",
                ),

              ],

            ),

          ),

          Expanded(

            child: PageView(

              controller: pageController,

              physics:
                  const NeverScrollableScrollPhysics(),

              onPageChanged: (index) {

                setState(() {

                  currentPage = index;

                });

              },

              children: [

                Center(

                  child: Text(

                    "STEP 1\n\nApplication Summary",

                    textAlign: TextAlign.center,

                    style: const TextStyle(

                      fontSize: 22,

                    ),

                  ),

                ),
                                Center(

                  child: Text(

                    "STEP 2\n\nTree-wise Final Decision\n\n(Tree decision cards will appear here)",

                    textAlign: TextAlign.center,

                    style: const TextStyle(

                      fontSize: 20,

                    ),

                  ),

                ),

                Padding(

                  padding: const EdgeInsets.all(16),

                  child: Column(

                    crossAxisAlignment:
                        CrossAxisAlignment.start,

                    children: [

                      const Text(

                        "RFO Overall Remarks",

                        style: TextStyle(

                          fontSize: 18,

                          fontWeight:
                              FontWeight.bold,

                        ),

                      ),

                      const SizedBox(height: 15),

                      TextField(

                        controller: remarksController,

                        maxLines: 8,

                        decoration:
                            const InputDecoration(

                          border:
                              OutlineInputBorder(),

                          hintText:
                              "Enter final remarks...",

                        ),

                        onChanged: (value) {

                          widget.application
                              .rfoOverallRemarks = value;

                        },

                      ),

                    ],

                  ),

                ),

                Center(

                  child: Text(

                    "STEP 4\n\nFinal Approval",

                    textAlign: TextAlign.center,

                    style: const TextStyle(

                      fontSize: 22,

                    ),

                  ),

                ),

              ],

            ),

          ),

          Container(

            padding:
                const EdgeInsets.all(15),

            child: Row(

              children: [

                if (currentPage > 0)

                  ElevatedButton(

                    onPressed: () {

                      pageController.previousPage(

                        duration:
                            const Duration(

                          milliseconds: 300,

                        ),

                        curve:
                            Curves.easeInOut,

                      );

                    },

                    child: const Text(

                      "Previous",

                    ),

                  ),

                const Spacer(),

                if (currentPage < 3)

                  ElevatedButton(

                    onPressed: () {

                      pageController.nextPage(

                        duration:
                            const Duration(

                          milliseconds: 300,

                        ),

                        curve:
                            Curves.easeInOut,

                      );

                    },

                    child: const Text(

                      "Next",

                    ),

                  )
                                  else

                  Row(

                    children: [

                      Expanded(

                        child: OutlinedButton.icon(

                          icon: const Icon(

                            Icons.reply,

                          ),

                          label: const Text(

                            "RETURN TO DRFO",

                          ),

                          onPressed: () async {

                            widget.application.status =
                                WorkflowStatus.pendingDRFOAssignment;

                            await applicationRepository
                                .updateApplication(

                              widget.application,

                            );

                            await historyRepository.addHistory(

                              officeNumber:
                                  widget.application.officeNumber,

                              action:
                                  "Returned to DRFO",

                              remarks:
                                  remarksController.text,

                              actionBy:
                                  SessionService.instance.name,

                            );

                            if (!mounted) return;

                            Navigator.pop(

                              context,

                              true,

                            );

                          },

                        ),

                      ),

                      const SizedBox(width: 15),

                      Expanded(

                        child: ElevatedButton.icon(

                          icon: const Icon(

                            Icons.check_circle,

                          ),

                          label: const Text(

                            "APPROVE",

                          ),

                          onPressed: () async {

                            widget.application
                                .rfoOverallRemarks =
                                remarksController.text;

                            widget.application.status =
                                WorkflowStatus.approved;

                            await applicationRepository
                                .updateApplication(

                              widget.application,

                            );

                            await historyRepository.addHistory(

                              officeNumber:
                                  widget.application.officeNumber,

                              action:
                                  HistoryActions.approved,

                              remarks:
                                  remarksController.text,

                              actionBy:
                                  SessionService.instance.name,

                            );

                            if (!mounted) return;

                            Navigator.pop(

                              context,

                              true,

                            );

                          },

                        ),

                      ),

                      const SizedBox(width: 15),

                      Expanded(

                        child: FilledButton.icon(

                          icon: const Icon(

                            Icons.cancel,

                          ),

                          label: const Text(

                            "REJECT",

                          ),

                          onPressed: () async {

                            widget.application
                                .rfoOverallRemarks =
                                remarksController.text;

                            widget.application.status =
                                WorkflowStatus.rejected;

                            await applicationRepository
                                .updateApplication(

                              widget.application,

                            );

                            await historyRepository.addHistory(

                              officeNumber:
                                  widget.application.officeNumber,

                              action:
                                  HistoryActions.rejected,

                              remarks:
                                  remarksController.text,

                              actionBy:
                                  SessionService.instance.name,

                            );

                            if (!mounted) return;

                            Navigator.pop(

                              context,

                              true,

                            );

                          },

                        ),

                      ),

                    ],

                  ),

              ],

            ),

          ),

        ],

      ),

    );

  }

}