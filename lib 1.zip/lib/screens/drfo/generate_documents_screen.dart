import 'package:flutter/material.dart';

import '../../models/application_model.dart';

class GenerateDocumentsScreen extends StatelessWidget {
  final ApplicationModel application;

  final VoidCallback onBack;
  final VoidCallback onSaveDraft;
  final VoidCallback onForward;

  const GenerateDocumentsScreen({
    super.key,
    required this.application,
    required this.onBack,
    required this.onSaveDraft,
    required this.onForward,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),

      child: Column(

        crossAxisAlignment:
            CrossAxisAlignment.stretch,

        children: [

          Card(

            child: Padding(

              padding: const EdgeInsets.all(20),

              child: Column(

                children: [

                  const Icon(
                    Icons.description,
                    size: 70,
                    color: Colors.green,
                  ),

                  const SizedBox(height: 15),

                  const Text(

                    "Generate DRFO Documents",

                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),

                  ),

                  const SizedBox(height: 10),

                  Text(
                    application.officeNumber,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 20),

                  const Text(
                    "Document generation will be added in the next step.",
                    textAlign: TextAlign.center,
                  ),

                ],

              ),

            ),

          ),

          const Spacer(),

        ],

      ),

    );
  }
}