import 'package:flutter/material.dart';

import '../../models/application_model.dart';
import '../../models/mahazar_model.dart';

import '../../repositories/mahazar_repository.dart';
import '../../repositories/mahazar_verification_repository.dart';
import '../../repositories/master_repository.dart';

import '../bfo/wizard/mahazar_step.dart';

class MahazarVerificationScreen extends StatefulWidget {

  final ApplicationModel application;

  const MahazarVerificationScreen({

    super.key,

    required this.application,

  });

  @override
  State<MahazarVerificationScreen> createState() =>
      MahazarVerificationScreenState();

}

class MahazarVerificationScreenState
    extends State<MahazarVerificationScreen> {

  final mahazarRepository =
      MahazarRepository();

  final verificationRepository =
      MahazarVerificationRepository();

  final masterRepository =
      MasterRepository();

  MahazarModel? mahazar;

  String? verification;

  List<String> reasons = [];

  @override
  void initState() {

    super.initState();

    load();

  }

  Future<void> load() async {

    mahazar =
        await mahazarRepository.getByApplication(
      widget.application.id!,
    );

    final existing =
        await verificationRepository
            .getVerification(
      widget.application.id!,
    );

    if (existing != null) {

      verification =
          existing["verification"];

    }

    reasons =
        await masterRepository
            .getVerificationReasons(
      "TREE",
    );

    if (mounted) {

      setState(() {});

    }

  }

  bool validateVerification() {

    if (verification == null) {

      ScaffoldMessenger.of(context)
          .showSnackBar(

        const SnackBar(

          content: Text(
            "Please verify Mahazar.",
          ),

        ),

      );

      return false;

    }

    return true;

  }

  Future<void> showReinspectDialog() async {

  String? selectedReason;

  await showDialog(

    context: context,

    builder: (_) {

      return AlertDialog(

        title: const Text(
          "Reason for Re-inspection",
        ),

        content: DropdownButtonFormField<String>(

          value: selectedReason,

          decoration: const InputDecoration(
            border: OutlineInputBorder(),
          ),

          items: reasons
              .map(
                (e) => DropdownMenuItem(
                  value: e,
                  child: Text(e),
                ),
              )
              .toList(),

          onChanged: (v) {

            selectedReason = v;

          },

        ),

        actions: [

          TextButton(

            onPressed: () {

              Navigator.pop(context);

            },

            child: const Text("Cancel"),

          ),

          ElevatedButton(

            onPressed: () async {

              if (selectedReason == null) {

                return;

              }

              await verificationRepository
                  .saveVerification(

                applicationId:
                    widget.application.id!,

                verification:
                    "Re-inspect",

                reason: selectedReason,

              );

              if (!mounted) return;

              Navigator.pop(context);

            },

            child: const Text("OK"),

          ),

        ],

      );

    },

  );

}

@override
Widget build(BuildContext context) {

  return Padding(

    padding: const EdgeInsets.all(16),

    child: SingleChildScrollView(

      child: Column(

        children: [

          Card(

            child: Padding(

              padding: const EdgeInsets.all(16),

              child: Column(

                crossAxisAlignment:
                    CrossAxisAlignment.start,

                children: [

                  const Text(

                    "Mahazar Details",

                    style: TextStyle(

                      fontSize: 18,

                      fontWeight: FontWeight.bold,

                    ),

                  ),

                  const Divider(),

                  ListTile(

                    title:
                        const Text("Mahazar Date"),

                    subtitle: Text(

                      mahazar?.mahazarDate ?? "",

                    ),

                  ),

                  ListTile(

                    title:
                        const Text("North"),

                    subtitle: Text(

                      mahazar?.northBoundary ?? "",

                    ),

                  ),

                  ListTile(

                    title:
                        const Text("East"),

                    subtitle: Text(

                      mahazar?.eastBoundary ?? "",

                    ),

                  ),

                  ListTile(

                    title:
                        const Text("South"),

                    subtitle: Text(

                      mahazar?.southBoundary ?? "",

                    ),

                  ),

                  ListTile(

                    title:
                        const Text("West"),

                    subtitle: Text(

                      mahazar?.westBoundary ?? "",

                    ),

                  ),

                ],

              ),

            ),

          ),

          const SizedBox(height:20),

          Card(

            child: Padding(

              padding: const EdgeInsets.all(16),

              child: Column(

                crossAxisAlignment:
                    CrossAxisAlignment.start,

                children: [

                  const Text(

                    "Verification",

                    style: TextStyle(

                      fontSize:18,

                      fontWeight:
                          FontWeight.bold,

                    ),

                  ),

                  const Divider(),

                  RadioListTile<String>(

                    value:"Correct",

                    groupValue:
                        verification,

                    title:
                        const Text("Correct"),

                    onChanged:(v) async {

                      verification=v;

                      setState((){});

                      await verificationRepository
                          .saveVerification(

                        applicationId:
                            widget.application.id!,

                        verification:v!,

                      );

                    },

                  ),

                  RadioListTile<String>(

                    value:"Modify",

                    groupValue:
                        verification,

                    title:
                        const Text("Modify"),

                    onChanged:(v) async {

                      verification=v;

                      setState((){});

                      await verificationRepository
                          .saveVerification(

                        applicationId:
                            widget.application.id!,

                        verification:v!,

                      );

                      await Navigator.push(

                        context,

                        MaterialPageRoute(

                          builder: (_) => MahazarStep(

                            application:
                                widget.application,

                            onBack: () {

                              Navigator.pop(context);

                            },

                            onNext: () {

                              Navigator.pop(context);

                            },

                          ),

                        ),

                      );

                      await load();

                    },

                  ),

                  RadioListTile<String>(

                    value:"Re-inspect",

                    groupValue:
                        verification,

                    title:
                        const Text(
                          "Re-inspect",
                        ),

                    onChanged:(v) async {

                      verification=v;

                      setState((){});

                      await verificationRepository
                          .saveVerification(

                        applicationId:
                            widget.application.id!,

                        verification:v!,

                      );

                      await showReinspectDialog();

                    },

                  ),

                ],

              ),

            ),

          ),

        ],

      ),

    ),

  );

}
}