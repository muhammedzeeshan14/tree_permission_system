import 'package:flutter/material.dart';

import '../../../models/application_model.dart';

import '../bfo/wizard/application_details_step.dart';
import '../bfo/wizard/inspection_decision_step.dart';
import '../bfo/wizard/application_type_step.dart';
import '../bfo/wizard/gps_step.dart';
import '../bfo/wizard/tree_step.dart';
import '../bfo/wizard/photo_step.dart';
import '../bfo/wizard/document_step.dart';
import '../bfo/wizard/revenue_opinion_step.dart';
import '../bfo/wizard/mahazar_step.dart';
import '../bfo/wizard/inspection_summary_step.dart';
import '../bfo/wizard/preview_submit_step.dart';
import '../../../repositories/inspection_defer_reason_repository.dart';

class DRFOSelfInspectionWizard extends StatefulWidget {

  final ApplicationModel application;

  const DRFOSelfInspectionWizard({
    super.key,
    required this.application,
  });

  @override
  State<DRFOSelfInspectionWizard> createState() =>
      _DRFOSelfInspectionWizardState();
}

class _DRFOSelfInspectionWizardState
    extends State<DRFOSelfInspectionWizard> {

      final InspectionDeferredReasonRepository deferredRepository =
    InspectionDeferredReasonRepository();

  int currentStep = 0;
  final int totalSteps = 11;

  void nextStep() {

  int next = currentStep + 1;

  // Skip Revenue Opinion
  if (next == 7 &&
      widget.application.applicationType != "PL" &&
      widget.application.applicationType != "SPL") {

    next = 8;

  }

  // Skip Mahazar for Tree Count
  if (next == 8 &&
      widget.application.permissionType == "Tree Count") {

    next = 9;

  }

  if (next >= totalSteps) {

    return;

  }

  setState(() {

    currentStep = next;

  });

}

void jumpToPreviewSubmit() {

  setState(() {

    currentStep = 10;

  });

}

  void previousStep() {

  // Preview screen after Deferred Inspection
  if (currentStep == 9 &&
      widget.application.inspectionDecision == "DEFERRED") {

    setState(() {
      currentStep = 1;
    });

    return;
  }

  if (currentStep == 0) {
    return;
  }

  setState(() {
    currentStep--;
  });

}

@override
void initState() {
  super.initState();
  loadDeferredReasons();
}

Future<void> loadDeferredReasons() async {
  if (widget.application.id == null) {
    return;
  }

  widget.application.deferredReasonIds =
      await deferredRepository.getReasonIds(
    widget.application.id!,
  );

  if (mounted) {
    setState(() {});
  }
}

@override
Widget build(BuildContext context) {

  switch (currentStep) {

    case 0:

      return ApplicationDetailsStep(

        application: widget.application,

        onNext: nextStep,

      );

    case 1:

      return InspectionDecisionStep(

        application: widget.application,

        onNext: nextStep,

        onBack: previousStep,

        onDeferred: jumpToPreviewSubmit,

      );

    case 2:

      return ApplicationTypeStep(

        application: widget.application,

        onBack: previousStep,

        onNext: nextStep,

      );

    case 3:

      return GPSStep(

        application: widget.application,

        onBack: previousStep,

        onNext: nextStep,

      );

    case 4:

      return TreeStep(

        application: widget.application,

        onBack: previousStep,

        onNext: nextStep,

      );

    case 5:

      return PhotoStep(

        application: widget.application,

        onBack: previousStep,

        onNext: nextStep,

      );

    case 6:

      return DocumentStep(

        application: widget.application,

        onBack: previousStep,

        onNext: nextStep,

      );

    case 7:

  return RevenueOpinionStep(

    application: widget.application,

    onBack: previousStep,

    onNext: nextStep,

  );
    case 8:

  return MahazarStep(

    application: widget.application,

    onBack: previousStep,

    onNext: nextStep,

  );

case 9:

  return InspectionSummaryStep(

    application: widget.application,

    onBack: previousStep,

    onNext: nextStep,

  );

case 10:

  return PreviewSubmitStep(

  application: widget.application,

  onBack: previousStep,

  isDRFOSelfInspection: true,

);
    default:

      return const Scaffold(

        body: Center(

          child: Text(

            "Next Step Coming...",

            style: TextStyle(

              fontSize: 22,

              fontWeight: FontWeight.bold,

            ),

          ),

        ),

      );

  }

}

}