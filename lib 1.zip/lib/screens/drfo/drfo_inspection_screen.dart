import 'package:flutter/material.dart';

import '../../models/application_model.dart';
import '../../services/workflow_service.dart';
import '../../services/session_service.dart';
import '../../constants/workflow_status.dart';
import '../../widgets/verification_card.dart';
import '../../repositories/master_repository.dart';
import '../../repositories/application_verification_repository.dart';
import 'tree_verification_screen.dart';
import '../../repositories/photo_repository.dart';
import '../../models/photo_model.dart';
import 'dart:io';
import '../../repositories/document_repository.dart';
import '../../models/document_model.dart';
import 'package:open_filex/open_filex.dart';
import '../bfo/wizard/inspection_summary_step.dart';
import 'generate_documents_screen.dart';
import '../../repositories/inspection_defer_reason_repository.dart';
import 'tree_count_verification_screen.dart';
import 'revenue_opinion_verification_screen.dart';
import 'mahazar_verification_screen.dart';

class DRFOInspectionScreen extends StatefulWidget {

  final ApplicationModel application;

  const DRFOInspectionScreen({

    super.key,

    required this.application,

  });

  @override
  State<DRFOInspectionScreen> createState() =>
      _DRFOInspectionScreenState();

}

class _DRFOInspectionScreenState
    extends State<DRFOInspectionScreen> {

final WorkflowService workflowService =
    WorkflowService();

final ApplicationVerificationRepository
    verificationRepository =
        ApplicationVerificationRepository();

  final PageController pageController =
      PageController();

      final GlobalKey<TreeVerificationScreenState>
    treeVerificationKey =
        GlobalKey<TreeVerificationScreenState>();

        final GlobalKey<TreeCountVerificationScreenState>
    treeCountVerificationKey =
        GlobalKey<TreeCountVerificationScreenState>();

        final GlobalKey<RevenueOpinionVerificationScreenState>
    revenueOpinionVerificationKey =
        GlobalKey<RevenueOpinionVerificationScreenState>();

        final GlobalKey<MahazarVerificationScreenState>
    mahazarVerificationKey =
        GlobalKey<MahazarVerificationScreenState>();

  int currentPage = 0;
  bool get isTreeCount {

  return widget.application.applicationType
          .trim()
          .toUpperCase() ==
      "RTC";

}

bool get needsRevenueOpinion {

  final type =
      widget.application.applicationType
          .trim()
          .toUpperCase();

  return type == "PL" ||
         type == "SPL";

}

bool get needsMahazar => !isTreeCount;
  bool get isDeferred =>
    widget.application.inspectionDecision == "DEFERRED";
  bool? applicationTypeCorrect;

bool? gpsCorrect;

bool? photosCorrect;

bool? documentsCorrect;

String? applicationTypeReason;
String? gpsReason;
String? photosReason;
String? documentsReason;
bool? deferredCorrect;

String? deferredReason;

List<String> deferredReasons = [];

final MasterRepository masterRepository = MasterRepository();
final PhotoRepository photoRepository = PhotoRepository();
final DocumentRepository documentRepository =
    DocumentRepository();

final InspectionDeferredReasonRepository
    deferredRepository =
        InspectionDeferredReasonRepository();

List<Map<String, dynamic>> selectedDeferredReasons = [];

List<DocumentModel> documents = [];

List<PhotoModel> photos = [];

List<String> applicationTypeReasons = [];
List<String> gpsReasons = [];
List<String> photoReasons = [];
List<String> documentReasons = [];

@override
void initState() {
  super.initState();

debugPrint(
    "Verified Type = ${widget.application.verifiedApplicationType}");

debugPrint(
    "Application Type = ${widget.application.applicationType}");

  _initialize();
}

Future<void> _initialize() async {

  await _loadVerificationReasons();

  selectedDeferredReasons =
      await deferredRepository.getReasons(
    widget.application.id!,
  );

  await _loadSavedVerification();

  if (mounted) {
    setState(() {});
  }

}

Future<void> _loadVerificationReasons() async {
  applicationTypeReasons =
      await masterRepository.getVerificationReasons(
    "APPLICATION_TYPE",
  );

  gpsReasons =
      await masterRepository.getVerificationReasons(
    "GPS",
  );

  photoReasons =
      await masterRepository.getVerificationReasons(
    "PHOTO",
  );

  documentReasons =
      await masterRepository.getVerificationReasons(
    "DOCUMENT",
  );

photos = await photoRepository.getPhotos(
  widget.application.id!,
);

documents =
    await documentRepository.getDocuments(
  widget.application.id!,
);

deferredReasons =
    await masterRepository.getVerificationReasons(
  "DEFERRED",
);

  if (mounted) {
    setState(() {});
  }
}

Future<void> _loadSavedVerification() async {

  final verification =
      await verificationRepository.getVerification(
    widget.application.id!,
  );

  if (verification == null) return;

  applicationTypeCorrect =
      verification["applicationTypeCorrect"] == 1;

  gpsCorrect =
      verification["gpsCorrect"] == 1;

  photosCorrect =
      verification["photosCorrect"] == 1;

  documentsCorrect =
      verification["documentsCorrect"] == 1;

  applicationTypeReason =
      verification["applicationTypeReason"];

  gpsReason =
      verification["gpsReason"];

  photosReason =
      verification["photosReason"];

  documentsReason =
      verification["documentsReason"];

  if (mounted) {
    setState(() {});
  }
}

Future<void> _saveVerification() async {
  await verificationRepository.saveVerification(
    applicationId: widget.application.id!,
    applicationTypeCorrect: applicationTypeCorrect ?? false,
    applicationTypeReason: applicationTypeReason,
    gpsCorrect: gpsCorrect ?? false,
    gpsReason: gpsReason,
    photosCorrect: photosCorrect ?? false,
    photosReason: photosReason,
    documentsCorrect: documentsCorrect ?? false,
    documentsReason: documentsReason,
    verifiedBy: SessionService.instance.name,
  );
}

void _showPhotos() {

  showDialog(

    context: context,

    builder: (_) {

      return Dialog(

        child: SizedBox(

          width: 900,
          height: 600,

          child: Column(

            children: [

              AppBar(

                automaticallyImplyLeading: false,

                title: Text(
                  "Inspection Photos (${photos.length})",
                ),

              ),

              Expanded(

                child: photos.isEmpty

                    ? const Center(
                        child: Text(
                          "No Photos Added",
                        ),
                      )

                    : GridView.builder(

                        padding:
                            const EdgeInsets.all(15),

                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(

                          crossAxisCount: 3,

                          crossAxisSpacing: 12,

                          mainAxisSpacing: 12,

                        ),

                        itemCount: photos.length,

                        itemBuilder: (_, index) {

                          final photo = photos[index];

                          return GestureDetector(

                            onTap: () {

                              showDialog(

                                context: context,

                                builder: (_) {

                                  return Dialog(

                                    child: InteractiveViewer(

                                      child: Image.file(

                                        File(photo.photoPath),

                                        fit: BoxFit.contain,

                                      ),

                                    ),

                                  );

                                },

                              );

                            },

                            child: Image.file(

                              File(photo.photoPath),

                              fit: BoxFit.cover,

                            ),

                          );

                        },

                      ),

              ),

              Padding(

                padding: const EdgeInsets.all(12),

                child: ElevatedButton(

                  onPressed: () {

                    Navigator.pop(context);

                  },

                  child: const Text("CLOSE"),

                ),

              ),

            ],

          ),

        ),

      );

    },

  );

}

void _showDocuments() {

  showDialog(

    context: context,

    builder: (_) {

      return Dialog(

        child: SizedBox(

          width: 750,

          height: 550,

          child: Column(

            children: [

              AppBar(

                automaticallyImplyLeading: false,

                title: Text(
                  "Uploaded Documents (${documents.length})",
                ),

              ),

              Expanded(

                child: documents.isEmpty

                    ? const Center(
                        child: Text(
                          "No Documents Uploaded",
                        ),
                      )

                    : ListView.builder(

                        itemCount: documents.length,

                        itemBuilder: (_, index) {

                          final doc =
                              documents[index];

                          return Card(

                            margin:
                                const EdgeInsets.all(8),

                            child: ListTile(

                              leading: const Icon(
                                Icons.description,
                                color: Colors.blue,
                              ),

                              title: Text(
                                doc.documentTypeName,
                              ),

                              subtitle: Text(
                                doc.remarks.isEmpty
                                    ? "-"
                                    : doc.remarks,
                              ),

                              trailing:
                                  ElevatedButton.icon(

                                icon: const Icon(
                                  Icons.visibility,
                                ),

                                label: const Text(
                                  "VIEW",
                                ),

                                onPressed: () async {

                                  await OpenFilex.open(
                                    doc.filePath,
                                  );

                                },

                              ),

                            ),

                          );

                        },

                      ),

              ),

              Padding(

                padding:
                    const EdgeInsets.all(12),

                child: ElevatedButton(

                  onPressed: () {

                    Navigator.pop(context);

                  },

                  child: const Text(
                    "CLOSE",
                  ),

                ),

              ),

            ],

          ),

        ),

      );

    },

  );

}

bool validateDeferredVerification() {

  if (deferredCorrect == null) {

    ScaffoldMessenger.of(context).showSnackBar(

      const SnackBar(

        content: Text(
          "Please verify deferred reason.",
        ),

      ),

    );

    return false;

  }

  if (deferredCorrect == false &&
      (deferredReason == null ||
          deferredReason!.isEmpty)) {

    ScaffoldMessenger.of(context).showSnackBar(

      const SnackBar(

        content: Text(
          "Please select verification reason.",
        ),

      ),

    );

    return false;

  }

  return true;

}

bool validateApplicationVerification() {

  if (applicationTypeCorrect == null) {

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          "Please verify Application Type.",
        ),
      ),
    );

    return false;
  }

  if (gpsCorrect == null) {

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          "Please verify GPS.",
        ),
      ),
    );

    return false;
  }

  if (photosCorrect == null) {

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          "Please verify Inspection Photos.",
        ),
      ),
    );

    return false;
  }

  if (documentsCorrect == null) {

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          "Please verify Uploaded Documents.",
        ),
      ),
    );

    return false;
  }

  return true;
}

bool hasAnyReInspection() {

  if (applicationTypeCorrect == false ||
      gpsCorrect == false ||
      photosCorrect == false ||
      documentsCorrect == false) {
    return true;
  }

  if (isTreeCount) {

    if (treeCountVerificationKey.currentState
            ?.verification ==
        "Re-inspect") {
      return true;
    }

  } else {

    if (treeVerificationKey.currentState
            ?.verificationStatus
            .values
            .contains("Re-inspect") ==
        true) {
      return true;
    }

  }

  if (needsRevenueOpinion) {

    if (revenueOpinionVerificationKey
            .currentState
            ?.verification ==
        "Re-inspect") {
      return true;
    }

  }

  if (needsMahazar) {

    if (mahazarVerificationKey
            .currentState
            ?.verification ==
        "Re-inspect") {
      return true;
    }

  }

  return false;

}

@override
Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        centerTitle: true,

        title: const Text(

          "DRFO Verification",

        ),

      ),

      body: Column(

        children: [

          Container(

  width: double.infinity,

  color: Colors.green.shade50,

  padding: const EdgeInsets.all(12),

  child: Column(

    crossAxisAlignment: CrossAxisAlignment.start,

    children: [

      Text(

        widget.application.officeNumber,

        style: const TextStyle(

          fontWeight: FontWeight.bold,

          fontSize: 18,

        ),

      ),

      const SizedBox(height: 5),

      Text(
        "Applicant : ${widget.application.applicantName}",
      ),

      Text(
        "Application Type : ${widget.application.applicationType}",
      ),

      Text(
        "Section : ${widget.application.section}",
      ),

      Text(
        "Beat : ${widget.application.beat}",
      ),

    ],

  ),

),

          Expanded(

            child: PageView(

              controller: pageController,

              physics:
                  const NeverScrollableScrollPhysics(),

              onPageChanged: (index) {

                setState(() {

                  currentPage = index;

                });

              },

              children: [

                InspectionSummaryStep(

  application: widget.application,

  showNavigationButtons: false,

  onBack: () {},

  onNext: () {},

),

if (isDeferred)

SingleChildScrollView(

  padding: const EdgeInsets.all(16),

  child: Column(

    children: [

      Card(

        child: Padding(

          padding: const EdgeInsets.all(16),

          child: Column(

            crossAxisAlignment:
                CrossAxisAlignment.start,

            children: [

              const Text(

                "Deferred Reasons",

                style: TextStyle(

                  fontSize: 18,

                  fontWeight: FontWeight.bold,

                ),

              ),

              const Divider(),

              if (widget.application.inspectionDecision == "DEFERRED")

                if (selectedDeferredReasons.isEmpty)

  const Text(
    "No deferred reasons found.",
  )

else

  Column(

    crossAxisAlignment:
        CrossAxisAlignment.start,

    children:

        selectedDeferredReasons.map((reason) {

      return Padding(

        padding:
            const EdgeInsets.only(bottom: 8),

        child: Row(

          children: [

            const Icon(

              Icons.check_circle,

              color: Colors.green,

              size: 18,

            ),

            const SizedBox(width: 8),

            Expanded(

              child: Text(

                reason["reasonName"],

                style: const TextStyle(
                  fontSize: 16,
                ),

              ),

            ),

          ],

        ),

      );

    }).toList(),

  ),

            ],

          ),

        ),

      ),

      const SizedBox(height: 15),

      VerificationCard(

        title: "Deferred Verification",

        value: "Verify the deferred inspection.",

        verification: deferredCorrect,

        selectedReason: deferredReason,

        reasons: deferredReasons,

        onReasonChanged: (value) async {

          setState(() {

            deferredReason = value;

          });

        },

        onChanged: (value) {

          setState(() {

            deferredCorrect = value;

          });

        },

      ),

    ],

  ),

),

                               if (!isDeferred)

SingleChildScrollView(

  child:
  Column(
    children: [

Row(
  children: [

    Expanded(
      child: VerificationCard(
  title: "Application Type",
  value: widget.application.applicationType,

  verification: applicationTypeCorrect,

  selectedReason: applicationTypeReason,

  reasons: applicationTypeReasons,

  onReasonChanged: (value) async {

    setState(() {
      applicationTypeReason = value;
    });

    await _saveVerification();
  },

  onChanged: (value) async {

    setState(() {
      applicationTypeCorrect = value;
    });

    await _saveVerification();
  },
),
    ),

    const SizedBox(width: 12),

    Expanded(
      child: VerificationCard(
  title: "GPS",
  value: "${photos.length} GPS Recorded",

  verification: gpsCorrect,

  selectedReason: gpsReason,

  reasons: gpsReasons,

  onReasonChanged: (value) async {

    setState(() {
      gpsReason = value;
    });

    await _saveVerification();
  },

  onChanged: (value) async {

    setState(() {
      gpsCorrect = value;
    });

    await _saveVerification();
  },
),
    ),

  ],
),

const SizedBox(height: 12),

Row(
  children: [

    Expanded(
      child: VerificationCard(
  title: "Inspection Photos",
  value: "${photos.length} Photo(s)",

  verification: photosCorrect,

  selectedReason: photosReason,

  reasons: photoReasons,

  onReasonChanged: (value) async {

    setState(() {
      photosReason = value;
    });

    await _saveVerification();
  },

  onChanged: (value) async {

    setState(() {
      photosCorrect = value;
    });

    await _saveVerification();
  },

  onView: _showPhotos,
),
    ),

    const SizedBox(width: 12),

    Expanded(
      child: VerificationCard(
  title: "Uploaded Documents",
  value: "${documents.length} Document(s)",

  verification: documentsCorrect,

  selectedReason: documentsReason,

  reasons: documentReasons,

  onReasonChanged: (value) async {

    setState(() {
      documentsReason = value;
    });

    await _saveVerification();
  },

  onChanged: (value) async {

    setState(() {
      documentsCorrect = value;
    });

    await _saveVerification();
  },

  onView: _showDocuments,
),
    ),

  ],
),

        ],
  ),

),

              isTreeCount
    ? TreeCountVerificationScreen(
  key: treeCountVerificationKey,
  application: widget.application,
)
    : TreeVerificationScreen(
        key: treeVerificationKey,
        application: widget.application,
      ),

if (needsRevenueOpinion)
  RevenueOpinionVerificationScreen(
    key: revenueOpinionVerificationKey,
    application: widget.application,
  ),

if (needsMahazar)
  MahazarVerificationScreen(
    key: mahazarVerificationKey,
    application: widget.application,
  ),

if (!hasAnyReInspection())

  GenerateDocumentsScreen(

    application: widget.application,

    onBack: () {

      if (isDeferred) {

        pageController.jumpToPage(1);

      } else {

        pageController.previousPage(

          duration:
              const Duration(milliseconds: 300),

          curve: Curves.easeInOut,

        );

      }

    },

    onSaveDraft: () async {

      ScaffoldMessenger.of(context).showSnackBar(

        const SnackBar(

          content: Text(
            "Draft Saved Successfully.",
          ),

        ),

      );

    },

    onForward: () {},

  ),
                

              ],

            ),

          ),

        Container(

  padding: const EdgeInsets.all(15),

  child: Row(

    children: [

      if (currentPage > 0)

        Expanded(

          child: OutlinedButton(

            style: OutlinedButton.styleFrom(

              minimumSize: const Size.fromHeight(55),

              shape: RoundedRectangleBorder(

                borderRadius:
                    BorderRadius.circular(18),

              ),

            ),

            onPressed: () {

              if (currentPage == 3 && isDeferred) {

                pageController.jumpToPage(1);

                return;

              }

              pageController.previousPage(

                duration:
                    const Duration(milliseconds: 300),

                curve: Curves.easeInOut,

              );

            },

            child: const Text(

              "PREVIOUS",

              style: TextStyle(

                fontSize: 18,

                fontWeight: FontWeight.bold,

              ),

            ),

          ),

        ),

      if (currentPage > 0)

        const SizedBox(width: 15),

      if (isDeferred &&
          currentPage == 1 &&
          deferredCorrect == false)

        Expanded(

          child: ElevatedButton(

            style: ElevatedButton.styleFrom(

              backgroundColor: Colors.orange,

              minimumSize:
                  const Size.fromHeight(55),

              shape: RoundedRectangleBorder(

                borderRadius:
                    BorderRadius.circular(18),

              ),

            ),

            onPressed: () async {

              if (!validateDeferredVerification()) {

                return;

              }

              await workflowService.returnToBFO(

                application: widget.application,

                actionBy:
                    SessionService.instance.name,

              );

              if (!mounted) return;

              ScaffoldMessenger.of(context)
                  .showSnackBar(

                const SnackBar(

                  content: Text(

                    "Returned for Re-inspection.",

                  ),

                ),

              );

              Navigator.pop(context, true);

            },

            child: Text(

              widget.application
                          .assignedBFOId ==
                      0

                  ? "RETURN TO SELF INSPECT"

                  : "RETURN TO BFO",

              style: const TextStyle(

                fontSize: 18,

                fontWeight: FontWeight.bold,

              ),

            ),

          ),

        )

      else if (

    currentPage <

    ((needsRevenueOpinion
            ? 5
            : needsMahazar
                ? 4
                : 3)

        -

        (hasAnyReInspection() ? 1 : 0))

)

        Expanded(

          child: ElevatedButton(

            style: ElevatedButton.styleFrom(

              minimumSize:
                  const Size.fromHeight(55),

              shape: RoundedRectangleBorder(

                borderRadius:
                    BorderRadius.circular(18),

              ),

            ),

            onPressed: () async {

                            //--------------------------------------------------
              // Deferred Verification
              //--------------------------------------------------

              if (isDeferred && currentPage == 1) {

                if (!validateDeferredVerification()) {
                  return;
                }

                if (deferredCorrect == true) {

                  pageController.jumpToPage(3);

                }

                return;
              }

              //--------------------------------------------------
              // Application Verification
              //--------------------------------------------------

              if (!isDeferred && currentPage == 1) {

                if (!validateApplicationVerification()) {
                  return;
                }

              }

              //--------------------------------------------------
              // Tree Verification
              //--------------------------------------------------

             if (currentPage == 2) {

  final applicationReinspect =
      applicationTypeCorrect == false ||
      gpsCorrect == false ||
      photosCorrect == false ||
      documentsCorrect == false;

  bool verificationReinspect = false;

  if (isTreeCount) {

    final valid =
        treeCountVerificationKey.currentState
                ?.validateVerification() ??
            false;

    if (!valid) return;

    verificationReinspect =
        treeCountVerificationKey.currentState!
                .verification ==
            "Re-inspect";

  } else {

    final valid =
        treeVerificationKey.currentState
                ?.validateVerification() ??
            false;

    if (!valid) return;

    verificationReinspect =
        treeVerificationKey.currentState!
            .verificationStatus
            .values
            .contains("Re-inspect");

  }

 if (!mounted) return;
 }

//==================================================
// Revenue Opinion Verification
//==================================================

if (currentPage == 3 && needsRevenueOpinion) {

  final valid =
      revenueOpinionVerificationKey.currentState
              ?.validateVerification() ??
          false;

  if (!valid) return;

  final reInspect =
      revenueOpinionVerificationKey.currentState!
              .verification ==
          "Re-inspect";

  if (!mounted) return;

}

//==================================================
// Mahazar Verification
//==================================================

if (

currentPage ==

(needsRevenueOpinion ? 4 : 3)

&&

needsMahazar

) {

  final valid =
      mahazarVerificationKey.currentState
              ?.validateVerification() ??
          false;

  if (!valid) return;

  final reInspect =
      mahazarVerificationKey.currentState!
              .verification ==
          "Re-inspect";

 if (!mounted) return;

}

// Move to next verification page
  pageController.nextPage(

    duration: const Duration(milliseconds: 300),

    curve: Curves.easeInOut,

  );

  return;

            },

            child: const Text(

              "NEXT",

              style: TextStyle(

                fontSize: 18,

                fontWeight: FontWeight.bold,

              ),

            ),

          ),

        )

      else

        Expanded(

          child: Row(

            children: [

              Expanded(

                child: OutlinedButton(

                  style: OutlinedButton.styleFrom(

                    minimumSize:
                        const Size.fromHeight(55),

                    shape: RoundedRectangleBorder(

                      borderRadius:
                          BorderRadius.circular(18),

                    ),

                  ),

                  onPressed: () async {

  ScaffoldMessenger.of(context).showSnackBar(

    const SnackBar(

      content: Text(
        "Draft Saved Successfully.",
      ),

    ),

  );

},

                  child: const Text(

                    "SAVE DRAFT",

                    style: TextStyle(

                      fontSize: 18,

                      fontWeight: FontWeight.bold,

                    ),

                  ),

                ),

              ),

              const SizedBox(width: 15),

              Expanded(

                child: ElevatedButton(

                  style: ElevatedButton.styleFrom(

                    minimumSize:
                        const Size.fromHeight(55),

                    shape: RoundedRectangleBorder(

                      borderRadius:
                          BorderRadius.circular(18),

                    ),

                  ),

                  onPressed: () async {

bool applicationReinspect =
    applicationTypeCorrect == false ||
    gpsCorrect == false ||
    photosCorrect == false ||
    documentsCorrect == false;

bool treeReinspect = false;

if (isTreeCount) {

  treeReinspect =
      treeCountVerificationKey.currentState
              ?.verification ==
          "Re-inspect";

} else {

  treeReinspect =
      treeVerificationKey.currentState
              ?.verificationStatus
              .values
              .contains("Re-inspect") ??
          false;

}

bool revenueReinspect = false;

if (needsRevenueOpinion) {

  revenueReinspect =
      revenueOpinionVerificationKey
              .currentState
              ?.verification ==
          "Re-inspect";

}

bool mahazarReinspect = false;

if (needsMahazar) {

  mahazarReinspect =
      mahazarVerificationKey
              .currentState
              ?.verification ==
          "Re-inspect";

}

bool hasReinspect =

    applicationReinspect ||

    treeReinspect ||

    revenueReinspect ||

    mahazarReinspect;

                    if (hasReinspect) {

  if (widget.application.assignedBFOId == 0) {

    await workflowService.returnToSelfInspection(

      application: widget.application,

      actionBy: SessionService.instance.name,

    );

  } else {

    await workflowService.returnToBFO(

      application: widget.application,

      actionBy: SessionService.instance.name,

    );

  }

  if (!mounted) return;

  ScaffoldMessenger.of(context).showSnackBar(

    const SnackBar(

      content: Text(

        "Application Returned for Re-inspection.",

      ),

    ),

  );

  Navigator.pop(context, true);

  return;

}
if (!hasReinspect) {
await workflowService.forwardToRFO(

  application: widget.application,

  actionBy: SessionService.instance.name,

);

if (!mounted) return;

ScaffoldMessenger.of(context).showSnackBar(

  const SnackBar(

    content: Text(

      "Application forwarded to RFO.",

    ),

  ),

);

Navigator.pop(context, true);
}

                  },

child: Text(

  hasAnyReInspection()
      ? (widget.application.assignedBFOId == 0
          ? "RETURN TO SELF INSPECT"
          : "RETURN TO BFO")
      : "FORWARD TO RFO",

  style: const TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.bold,
  ),

),

),

                ),

            ],

          ),
          
          ],

        ),

      ),

    );

  }

}