import 'package:flutter/material.dart';

import '../../services/session_service.dart';
import '../../widgets/tpms_drawer.dart';
import 'application_list_screen.dart';
import 'new_application_screen.dart';

class CaseWorkerDashboardScreen extends StatelessWidget {
  const CaseWorkerDashboardScreen({
    super.key,
  });

  @override
  Widget build(BuildContext context) {

    final session =
        SessionService.instance;

    return Scaffold(

  drawer: const TPMSDrawer(),

      appBar: AppBar(

        centerTitle: true,

        title: const Text(
          "Case Worker Dashboard",
        ),

      ),

      body: ListView(

        padding: const EdgeInsets.all(16),

        children: [

          Card(

            elevation: 4,

            child: Padding(

              padding:
                  const EdgeInsets.all(16),

              child: Column(

                crossAxisAlignment:
                    CrossAxisAlignment.start,

                children: [

                  const Text(

                    "Welcome",

                    style: TextStyle(

                      fontSize: 16,

                    ),

                  ),

                  const SizedBox(height: 5),

                  Text(

                    session.name,

                    style: const TextStyle(

                      fontSize: 22,

                      fontWeight:
                          FontWeight.bold,

                    ),

                  ),

                  const SizedBox(height: 8),

                  Text(

                    "Role : ${session.role}",

                  ),

                ],

              ),

            ),

          ),

          const SizedBox(height: 15),

          Card(

            child: ListTile(

              leading: const Icon(

                Icons.add_circle,

                color: Colors.green,

              ),

              title: const Text(

                "New Application",

              ),

              subtitle: const Text(

                "Create new tree permission application",

              ),

              trailing:
                  const Icon(Icons.arrow_forward_ios),

              onTap: () {

                Navigator.push(

                  context,

                  MaterialPageRoute(

                    builder: (_) =>
                        const NewApplicationScreen(),

                  ),

                );

              },

            ),

          ),
                    const SizedBox(height: 15),

          Card(

            child: ListTile(

              leading: const Icon(

                Icons.folder,

                color: Colors.blue,

              ),

              title: const Text(

                "My Applications",

              ),

              subtitle: const Text(

                "View applications created by you",

              ),

              trailing: const Icon(

                Icons.arrow_forward_ios,

              ),

              onTap: () {

                Navigator.push(

                  context,

                  MaterialPageRoute(

                    builder: (_) =>

                        const ApplicationListScreen(),

                  ),

                );

              },

            ),

          ),

          const SizedBox(height: 15),

        ],

      ),

    );

  }

}