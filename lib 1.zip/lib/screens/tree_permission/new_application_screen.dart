import 'package:flutter/material.dart';
import '../../repositories/application_repository.dart';
import '../../repositories/history_repository.dart';
import '../../models/application_model.dart';
import '../../services/application_service.dart';
import '../../services/master_service.dart';
import '../../repositories/master_repository.dart';
import '../../repositories/application_type_repository.dart';
import '../../repositories/section_repository.dart';
import '../../repositories/beat_repository.dart';
import '../../repositories/forwarded_source_repository.dart';
import '../../widgets/forwarded_reference_widget.dart';
import '../../services/session_service.dart';
import '../../utils/date_picker_util.dart';
import '../../repositories/application_type_permission_mapping_repository.dart';

class NewApplicationScreen extends StatefulWidget {

  final ApplicationModel? application;

  const NewApplicationScreen({

    super.key,

    this.application,

  });

  @override
  State<NewApplicationScreen> createState() =>
      _NewApplicationScreenState();
}

class _NewApplicationScreenState
    extends State<NewApplicationScreen> {

  final applicationDateController = TextEditingController();
  final receivedDateController = TextEditingController();

  final applicantNameController = TextEditingController();
  final applicantAddressController = TextEditingController();

final treeLocationController = TextEditingController();

final mobileController = TextEditingController();

  final purposeController = TextEditingController();
  // ===========================
// EDIT MODE
// ===========================

bool get isEdit =>
    widget.application != null;
  List<Map<String, dynamic>> purposeList = [];
  List<Map<String, dynamic>> applicationTypeList = [];
  List<Map<String, dynamic>> sectionList = [];
  List<Map<String, dynamic>> beatList = [];
  List<Map<String, dynamic>> forwardedSourceList = [];

String applicationSource = "DIRECT";

String forwardedDate = "";

List<ForwardReference> forwardReferences = [];

  String applicationType = "PL";

  String section = "";
String beat = "";

bool treeLocationSame = true;
  String formatDate(String value) {
  List<String> p = value.split("/");

  if (p.length != 3) return value;

  String day = p[0].padLeft(2, "0");
  String month = p[1].padLeft(2, "0");
  String year = p[2];

  if (year.length == 2) {
    year = "20$year";
  }

  return "$day/$month/$year";
}

@override
void initState() {
  super.initState();

  initializeScreen();
}
Future<void> initializeScreen() async {

  applicationDateController.text = "DD/MM/YYYY";
  receivedDateController.text = "DD/MM/YYYY";

  await loadPurpose();

  await loadApplicationTypes();

  await loadSections();
  await loadForwardedSources();

  if (isEdit) {

    applicationDateController.text =
        widget.application!.applicationDate;

    receivedDateController.text =
        widget.application!.receivedDate;

    applicantNameController.text =
        widget.application!.applicantName;

    applicantAddressController.text =
        widget.application!.applicantAddress;

    mobileController.text =
        widget.application!.mobile;

    purposeController.text =
        widget.application!.purpose;

    applicationType =
        widget.application!.applicationType;

    section =
        widget.application!.section;

    await loadBeats();

    beat =
        widget.application!.beat;

  }

  if (mounted) {
    setState(() {});
  }

}
Future<void> loadPurpose() async {

  purposeList =
      await MasterRepository().getMasters("Purpose");

  if (mounted) {
    setState(() {});
  }

}
Future<void> loadApplicationTypes() async {

  applicationTypeList =
      await ApplicationTypeRepository().getAll();

  if (mounted) {

    setState(() {});

  }

}
Future<void> loadSections() async {

  sectionList =
      await SectionRepository().getAll();

  if (mounted) {
    setState(() {});
  }

}
Future<void> loadBeats() async {

  if (section.isEmpty) {

    beatList = [];

    if (mounted) {
      setState(() {});
    }

    return;

  }

  final selectedSection = sectionList.firstWhere(

    (e) => e["sectionName"] == section,

  );

  beatList = await BeatRepository().getBySection(

    selectedSection["id"],

  );

  if (mounted) {

    setState(() {});

  }

}

Future<void> loadForwardedSources() async {

  forwardedSourceList =
      await ForwardedSourceRepository()
          .getSources();

  if (mounted) {

    setState(() {});

  }

}

  @override
  Widget build(BuildContext context) {

    final officeNo =
        ApplicationService.generateOfficeNumber(applicationType);

    return Scaffold(
      appBar: AppBar(
        title: const Text(
            "New Tree Permission Application"),
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),

        child: Column(
          children: [

            TextFormField(
              initialValue: officeNo,
              readOnly: true,
              decoration: const InputDecoration(
                labelText: "Office Number",
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 15),

            ForwardedReferenceWidget(

  applicationSource: applicationSource,

  forwardedDate: forwardedDate,

  references: forwardReferences,

  sourceList: forwardedSourceList,

  onSourceChanged: (value) {

    setState(() {

      applicationSource = value;

    });

  },

  onForwardedDateChanged: (value) {

    forwardedDate = value;

  },

  onAddReference: () {

    setState(() {

      forwardReferences.add(

        ForwardReference(),

      );

    });

  },

  onRemoveReference: (index) {

    setState(() {

      forwardReferences.removeAt(index);

    });

  },

  onSourceSelected: (

    index,

    sourceId,

    sourceName,

  ) {

    forwardReferences[index].sourceId = sourceId;

    forwardReferences[index].sourceName = sourceName;

  },

  onReferenceNumberChanged: (

    index,

    value,

  ) {

    forwardReferences[index].referenceNumber = value;

  },

  onReferenceDateChanged: (

    index,

    value,

  ) {

    forwardReferences[index].referenceDate = value;

  },

),

const SizedBox(height: 15),

            TextFormField(
  controller: applicationDateController,
  readOnly: true,
  onTap: () async {
    await DatePickerUtil.pickDate(
      context,
      applicationDateController,
    );
  },
  decoration: const InputDecoration(
    labelText: "Date of Application",
    border: OutlineInputBorder(),
    suffixIcon: Icon(Icons.calendar_month),
  ),
),

            const SizedBox(height: 15),

TextFormField(
  controller: receivedDateController,
  readOnly: true,
  onTap: () async {
    await DatePickerUtil.pickDate(
      context,
      receivedDateController,
    );
  },
  decoration: const InputDecoration(
    labelText: "Date Received",
    border: OutlineInputBorder(),
    suffixIcon: Icon(Icons.calendar_month),
  ),
),

            const SizedBox(height: 15),

            TextFormField(
              controller: applicantNameController,
              textInputAction: TextInputAction.next,
              decoration: const InputDecoration(
                labelText: "Applicant Name",
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 15),

            TextFormField(
  controller: applicantAddressController,
  maxLines: 3,
  textInputAction: TextInputAction.next,
  onChanged: (value) {

    if (treeLocationSame) {

      treeLocationController.text = value;

    }

  },
  decoration: const InputDecoration(
    labelText: "Applicant Address",
    border: OutlineInputBorder(),
  ),
),

const SizedBox(height: 15),

const Align(
  alignment: Alignment.centerLeft,
  child: Text(
    "Location of Tree(s)",
    style: TextStyle(
      fontWeight: FontWeight.bold,
      fontSize: 15,
    ),
  ),
),

Row(
  children: [

    Expanded(
      child: RadioListTile<bool>(
        dense: true,
        value: true,
        groupValue: treeLocationSame,
        title: const Text("Same"),
        onChanged: (value) {

          setState(() {

            treeLocationSame = true;

            treeLocationController.text =
                applicantAddressController.text;

          });

        },
      ),
    ),

    Expanded(
      child: RadioListTile<bool>(
        dense: true,
        value: false,
        groupValue: treeLocationSame,
        title: const Text("Different"),
        onChanged: (value) {

          setState(() {

            treeLocationSame = false;

          });

        },
      ),
    ),

  ],
),

TextFormField(
  controller: treeLocationController,
  enabled: !treeLocationSame,
  maxLines: 3,
  decoration: const InputDecoration(
    labelText: "Location of Tree(s)",
    border: OutlineInputBorder(),
  ),
),

            const SizedBox(height: 15),

            TextFormField(
              controller: mobileController,
              keyboardType: TextInputType.phone,
              textInputAction: TextInputAction.next,
              decoration: const InputDecoration(
                labelText: "Mobile",
                border: OutlineInputBorder(),
              ),
            ),

const SizedBox(height: 15),
            DropdownButtonFormField<String>(

  value: purposeList.any(
        (e) => e["value"] == purposeController.text)
    ? purposeController.text
    : null,

  decoration: const InputDecoration(

    labelText: "Purpose",

    border: OutlineInputBorder(),

  ),

  items: purposeList.map((item) {

    return DropdownMenuItem<String>(

      value: item["value"],

      child: Text(item["value"]),

    );

  }).toList(),

  onChanged: (value) {

    setState(() {

      purposeController.text = value ?? "";

    });

  },

),
            const SizedBox(height: 15),

            DropdownButtonFormField<String>(
  value: applicationTypeList.any(
          (e) => e["shortCode"] == applicationType)
      ? applicationType
      : null,

  decoration: const InputDecoration(
    labelText: "Application Type",
    border: OutlineInputBorder(),
  ),

  items: applicationTypeList.map((item) {

    return DropdownMenuItem<String>(

      value: item["shortCode"],

      child: Text(item["applicationType"]),

    );

  }).toList(),

  onChanged: (value) {

    setState(() {

      applicationType = value!;

    });

  },

),

            const SizedBox(height: 15),

DropdownButtonFormField<String>(

  value: sectionList.any(
        (e) => e["sectionName"] == section)
    ? section
    : null,

  decoration: const InputDecoration(

    labelText: "Section",

    border: OutlineInputBorder(),

  ),

  items: sectionList.map((item) {

    return DropdownMenuItem<String>(

      value: item["sectionName"],

      child: Text(item["sectionName"]),

    );

  }).toList(),

 onChanged: (value) async {

  setState(() {

    section = value!;

    beat = "";

  });

  await loadBeats();


}

),

const SizedBox(height: 15),

DropdownButtonFormField<String>(

  value: beatList.any(
        (e) => e["beatName"] == beat)
    ? beat
    : null,

  decoration: const InputDecoration(

    labelText: "Beat",

    border: OutlineInputBorder(),

  ),

  items: beatList.map((item) {

    return DropdownMenuItem<String>(

      value: item["beatName"],

      child: Text(

        item["beatName"],

      ),

    );

  }).toList(),

  onChanged: (value) {

    setState(() {

      beat = value!;

    });

  },

),

            const SizedBox(height: 30),

            SizedBox(
              width: double.infinity,
              height: 55,
              child: ElevatedButton(
                onPressed: () async {

                  final officeNumber = isEdit

    ? widget.application!.officeNumber

    : ApplicationService.generateOfficeNumber(
        applicationType,
      );

// SAVE APPLICATION
try {

final selectedApplicationType = applicationTypeList.firstWhere(
  (e) => e["shortCode"] == applicationType,
);

final permission =
    await ApplicationTypePermissionMappingRepository()
        .getPermissionForApplicationType(
  selectedApplicationType["id"],
);

   ApplicationModel application = ApplicationModel(

  id: isEdit

      ? widget.application!.id

      : null,
  officeNumber: officeNumber,

  applicationType: applicationType,

  verifiedApplicationType: applicationType,

  permissionTypeId: permission?["id"] as int?,

permissionType:
    permission?["permissionType"]?.toString() ?? "",

  applicationDate: formatDate(applicationDateController.text),

  receivedDate: formatDate(receivedDateController.text),

  applicantName: applicantNameController.text,

  applicantAddress: applicantAddressController.text,

  treeLocationSame: treeLocationSame,

treeLocationAddress: treeLocationSame
    ? applicantAddressController.text
    : treeLocationController.text,

  mobile: mobileController.text,

  applicationSource: applicationSource,

forwardedDate: forwardedDate,

  createdBy: SessionService.instance.userId,

sectionId: sectionList
        .where((e) => e["sectionName"] == section)
        .isEmpty
    ? null
    : sectionList.firstWhere(
        (e) => e["sectionName"] == section,
      )["id"],

beatId: beatList
        .where((e) => e["beatName"] == beat)
        .isEmpty
    ? null
    : beatList.firstWhere(
        (e) => e["beatName"] == beat,
      )["id"],
assignedBFOId: null,

assignedDRFOId: null,
section: section,

beat: beat,

  assignedBFO: "",

  assignedDRFO: "",

  purpose: purposeController.text,

  gpsCoordinates: "",

  bfoVerificationDate: "",

  inspectionStarted: false,

inspectionDecision: "",

deferredReasonIds: [],

overallRemarks: "",

  // DRFO
  drfoInspectionDate: "",

  drfoOverallRemarks: "",
  // RFO
rfoInspectionStarted: false,

rfoInspectionDate: "",

rfoOverallRemarks: "",

// RETURN TO DRFO

returnReason: "",

returnRemarks: "",

returnedBy: "",

returnedDate: "",


  trees: [],

status: "Draft",

inspectionMode: "",

createdDate: isEdit

    ? widget.application!.createdDate

    : DateTime.now(),
);

  if (isEdit) {


    await ApplicationRepository()
        .updateApplication(application);

    await HistoryRepository().addHistory(

      officeNumber: application.officeNumber,

      action: "Application Updated",

      remarks: "Draft updated by Case Worker",

      actionBy: SessionService.instance.name,

    );

  } else {

    await ApplicationRepository()
        .insertApplication(application);

    await HistoryRepository().addHistory(

      officeNumber: application.officeNumber,

      action: "Application Saved",

      remarks: "Saved as Draft",

      actionBy: SessionService.instance.name,

    );

  }

  if (!mounted) return;

  ScaffoldMessenger.of(context).showSnackBar(

    SnackBar(

      content: Text(

        isEdit

            ? "Application Updated"

            : "Application Saved",

      ),

    ),

  );

  Navigator.pop(context, true);

} catch (e) {

  ScaffoldMessenger.of(context).showSnackBar(

    SnackBar(

      content: Text("ERROR : $e"),

    ),

  );

}

                },
                child: Text(
  isEdit
      ? "UPDATE APPLICATION"
      : "SAVE APPLICATION",
  style: const TextStyle(fontSize: 18),
),
              ),
            ),
          ],
        ),
      ),
    );
  }
}