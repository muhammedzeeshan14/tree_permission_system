import 'package:sqflite/sqflite.dart';

import '../models/tree_model.dart';
import '../database/database_helper.dart';

class TreeRepository {
  Future<Database> get _db async =>
      await DatabaseHelper.instance.database;

  // Insert Tree
  Future<int> insertTree(TreeModel tree) async {
    final db = await _db;
    return await db.insert(
      'trees',
      tree.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // Update Tree
  Future<int> updateTree(TreeModel tree) async {
    final db = await _db;

    return await db.update(
      'trees',
      tree.toMap(),
      where: 'id=?',
      whereArgs: [tree.id],
    );
  }

  // Delete Tree
  Future<int> deleteTree(int id) async {
    final db = await _db;

    return await db.delete(
      'trees',
      where: 'id=?',
      whereArgs: [id],
    );
  }

  // Get Trees of one Application
  Future<List<TreeModel>> getTrees(
      int applicationId) async {
    final db = await _db;

    final result = await db.query(
      'trees',
      where: 'applicationId=?',
      whereArgs: [applicationId],
      orderBy: 'baseTreeNumber, stemSequence',
    );

    return result
        .map((e) => TreeModel.fromMap(e))
        .toList();
  }

  // Total Trees (Every Stem Counts)
  Future<int> getTreeCount(
      int applicationId) async {
    final db = await _db;

    final result = Sqflite.firstIntValue(
      await db.rawQuery(
        '''
        SELECT COUNT(*)
        FROM trees
        WHERE applicationId=?
        ''',
        [applicationId],
      ),
    );

    return result ?? 0;
  }

  // Get Last Tree
  Future<TreeModel?> getLastTree(
      int applicationId) async {
    final db = await _db;

    final result = await db.query(
      'trees',
      where: 'applicationId=?',
      whereArgs: [applicationId],
      orderBy: 'id DESC',
      limit: 1,
    );

    if (result.isEmpty) return null;

    return TreeModel.fromMap(result.first);
  }
  // Total Trees Alias
Future<int> totalTrees(
  int applicationId,
) async {
  return await getTreeCount(applicationId);
}
}