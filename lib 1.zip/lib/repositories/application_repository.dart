import 'package:sqflite/sqflite.dart';

import '../database/database_helper.dart';
import '../models/application_model.dart';
import '../constants/workflow_status.dart';

class ApplicationRepository {
  final DatabaseHelper dbHelper =
      DatabaseHelper.instance;

  Future<Database> get _db async =>
      await dbHelper.database;

  // ======================================
  // INSERT APPLICATION
  // ======================================

  Future<int> insertApplication(
    ApplicationModel application) async {

  final db = await _db;

  final id = await db.insert(

    "applications",

    {

      // BASIC

      "officeNumber": application.officeNumber,

      "applicationType": application.applicationType,

      "verifiedApplicationType":
          application.verifiedApplicationType,

          "permissionTypeId":
    application.permissionTypeId,

"permissionType":
    application.permissionType,

      "applicationDate":
          application.applicationDate,

      "receivedDate":
          application.receivedDate,

      "applicantName":
          application.applicantName,

      "applicantAddress":
          application.applicantAddress,

          "treeLocationSame":
    application.treeLocationSame ? 1 : 0,

"treeLocationAddress":
    application.treeLocationAddress,

      "mobile": application.mobile,

      "applicationSource": application.applicationSource,

"forwardedDate": application.forwardedDate,

      // IDs

      "createdBy":
          application.createdBy,

      "sectionId":
          application.sectionId,

      "beatId":
          application.beatId,

      "assignedBFO":
          application.assignedBFOId,

      "assignedDRFO":
          application.assignedDRFOId,

      // PURPOSE

      "purpose": application.purpose,

      // BFO

      "gps":
          application.gpsCoordinates,

      "inspectionStarted":
          application.inspectionStarted ? 1 : 0,
          "inspectionDecision":
    application.inspectionDecision,

      "bfoVerificationDate":
          application.bfoVerificationDate,

      "overallRemarks":
          application.overallRemarks,

      // DRFO

      "drfoInspectionDate":
          application.drfoInspectionDate,

      "drfoOverallRemarks":
          application.drfoOverallRemarks,

      // RFO

      "rfoInspectionStarted":
          application.rfoInspectionStarted ? 1 : 0,

      "rfoInspectionDate":
          application.rfoInspectionDate,

      "rfoOverallRemarks":
          application.rfoOverallRemarks,

      // RETURN

      "returnReason":
          application.returnReason,

      "returnRemarks":
          application.returnRemarks,

      "returnedBy":
          application.returnedBy,

      "returnedDate":
          application.returnedDate,

     // IMPORTANT

"status": "Draft",

"inspectionMode":
    application.inspectionMode,

"createdDate":
    application.createdDate
        .toIso8601String(),

    },

  );

  application.id = id;

  return id;

}

  // ======================================
  // UPDATE APPLICATION
  // ======================================

  Future<int> updateApplication(

    ApplicationModel application,

  ) async {

    final db = await _db;

    return await db.update(

      "applications",

      {
  "applicationType": application.applicationType,

  "verifiedApplicationType":
      application.verifiedApplicationType,

      "permissionTypeId":
    application.permissionTypeId,

"permissionType":
    application.permissionType,

  "applicationDate":
      application.applicationDate,

  "receivedDate":
      application.receivedDate,

  "applicantName":
      application.applicantName,

  "applicantAddress":
      application.applicantAddress,

      "treeLocationSame":
    application.treeLocationSame ? 1 : 0,

"treeLocationAddress":
    application.treeLocationAddress,

  "mobile":
      application.mobile,

      "applicationSource": application.applicationSource,

"forwardedDate": application.forwardedDate,

  "sectionId":
      application.sectionId,

  "beatId":
      application.beatId,

  "purpose":
      application.purpose,

  "gps":
      application.gpsCoordinates,

  "inspectionStarted":
      application.inspectionStarted ? 1 : 0,
      "inspectionDecision":
    application.inspectionDecision,

  "overallRemarks":
      application.overallRemarks,

  "bfoVerificationDate":
      application.bfoVerificationDate,

  "drfoInspectionDate":
      application.drfoInspectionDate,

  "drfoOverallRemarks":
      application.drfoOverallRemarks,

  "rfoInspectionStarted":
      application.rfoInspectionStarted ? 1 : 0,

  "rfoInspectionDate":
      application.rfoInspectionDate,

  "rfoOverallRemarks":
      application.rfoOverallRemarks,

  "returnReason":
      application.returnReason,

  "returnRemarks":
      application.returnRemarks,

  "returnedBy":
      application.returnedBy,

  "returnedDate":
      application.returnedDate,

  "status":
    application.status,

"inspectionMode":
    application.inspectionMode,
},

      where: "id=?",

whereArgs: [

  application.id,

],

    );

  }
  // ======================================
// GET APPLICATION BY ID
// ======================================

Future<ApplicationModel?> getById(
  int id,
) async {

  final db = await _db;

  final result = await db.query(

    "applications",

    where: "id=?",

    whereArgs: [id],

    limit: 1,

  );

  if (result.isEmpty) {

    return null;

  }

  return _mapApplication(result.first);

}
    // ======================================
  // APPLICATION MAPPER
  // ======================================

  ApplicationModel _mapApplication(
  Map<String, dynamic> row,
) {

  return ApplicationModel(

    id: row["id"] as int?,

    officeNumber:
        row["officeNumber"]?.toString() ?? "",

    applicationType:
        row["applicationType"]?.toString() ?? "",

    verifiedApplicationType:
        row["verifiedApplicationType"]?.toString() ?? "",

        permissionTypeId:
    row["permissionTypeId"] as int?,

permissionType:
    row["permissionType"]?.toString() ?? "",

    applicationDate:
        row["applicationDate"]?.toString() ?? "",

    receivedDate:
        row["receivedDate"]?.toString() ?? "",

    applicantName:
        row["applicantName"]?.toString() ?? "",

    applicantAddress:
        row["applicantAddress"]?.toString() ?? "",

        treeLocationSame:
    (row["treeLocationSame"] ?? 1) == 1,

treeLocationAddress:
    row["treeLocationAddress"]?.toString() ?? "",

    mobile:
    row["mobile"]?.toString() ?? "",

applicationSource:
    row["applicationSource"]?.toString() ?? "DIRECT",

forwardedDate:
    row["forwardedDate"]?.toString() ?? "",

createdBy:
    row["createdBy"] as int?,

    sectionId:
        row["sectionId"] as int?,

    beatId:
        row["beatId"] as int?,

    assignedBFOId:
        row["assignedBFO"] as int?,

    assignedDRFOId:
        row["assignedDRFO"] as int?,

    section:
    row["sectionName"]?.toString() ?? "",

beat:
    row["beatName"]?.toString() ?? "",

assignedBFO:
    row["assignedBFOName"]?.toString() ?? "",

assignedDRFO:
    row["assignedDRFOName"]?.toString() ?? "",

    purpose:
        row["purpose"]?.toString() ?? "",

    gpsCoordinates:
        row["gps"]?.toString() ?? "",

    bfoVerificationDate:
        row["bfoVerificationDate"]?.toString() ?? "",

    inspectionStarted:
        (row["inspectionStarted"] ?? 0) == 1,
       
        inspectionDecision:
    row["inspectionDecision"]?.toString() ?? "",

deferredReasonIds: [],

    overallRemarks:
        row["overallRemarks"]?.toString() ?? "",

    drfoInspectionDate:
        row["drfoInspectionDate"]?.toString() ?? "",

    drfoOverallRemarks:
        row["drfoOverallRemarks"]?.toString() ?? "",

    rfoInspectionStarted:
        (row["rfoInspectionStarted"] ?? 0) == 1,

    rfoInspectionDate:
        row["rfoInspectionDate"]?.toString() ?? "",

    rfoOverallRemarks:
        row["rfoOverallRemarks"]?.toString() ?? "",

    returnReason:
        row["returnReason"]?.toString() ?? "",

    returnRemarks:
        row["returnRemarks"]?.toString() ?? "",

    returnedBy:
        row["returnedBy"]?.toString() ?? "",

    returnedDate:
        row["returnedDate"]?.toString() ?? "",

    trees: [],

    status:
        row["status"]?.toString() ?? "",

    inspectionMode:
    row["inspectionMode"]?.toString() ?? "",    

    createdDate:
        DateTime.tryParse(
              row["createdDate"]?.toString() ?? "",
            ) ??
            DateTime.now(),

  );

}

// ======================================
// GET ALL APPLICATIONS
// ======================================

Future<List<ApplicationModel>>
    getApplications() async {

  final db = await _db;

  final result = await db.rawQuery("""

SELECT

applications.*,

section_master.sectionName,

beat_master.beatName,

bfo.name AS assignedBFOName,

drfo.name AS assignedDRFOName

FROM applications

LEFT JOIN section_master

ON applications.sectionId = section_master.id

LEFT JOIN beat_master

ON applications.beatId = beat_master.id

LEFT JOIN users bfo

ON applications.assignedBFO = bfo.id

LEFT JOIN users drfo

ON applications.assignedDRFO = drfo.id

ORDER BY applications.createdDate DESC

""");

  return result
      .map(_mapApplication)
      .toList();

}
// ======================================
// CASE WORKER APPLICATIONS
// ======================================

Future<List<ApplicationModel>>
    getApplicationsForCaseWorker(
        int userId) async {

  final all = await getApplications();

  return all.where((app) {

    return app.createdBy == userId &&
        (app.status == "Draft" ||
         app.status == "Pending DRFO Assignment" ||
         app.status == "Returned to Case Worker");

  }).toList();

}
// ======================================
// DRFO APPLICATIONS
// ======================================

Future<List<ApplicationModel>>
    getApplicationsForDRFO(
        int sectionId) async {

  final all = await getApplications();

  return all.where((app) {

    return app.sectionId == sectionId && (

      app.status == WorkflowStatus.pendingDRFOAssignment ||

      app.status == WorkflowStatus.pendingBFOInspection ||

      app.status == WorkflowStatus.pendingDRFOVerification ||

      app.status == WorkflowStatus.pendingDRFOSelfInspection ||

      app.status == WorkflowStatus.pendingDRFOReSelfInspection ||

      app.status == WorkflowStatus.returnedToBFO

    );

  }).toList();

}

// ======================================
// BFO APPLICATIONS
// ======================================

Future<List<ApplicationModel>>
    getApplicationsForBFO(
        int userId) async {

  final all = await getApplications();

  return all.where((app) {

    return app.assignedBFOId == userId && (

    app.status ==
        WorkflowStatus.pendingBFOInspection ||

    app.status ==
        WorkflowStatus.returnedToBFO

);

  }).toList();

}
// ======================================
// RFO APPLICATIONS
// ======================================

Future<List<ApplicationModel>>
    getApplicationsForRFO() async {

  final all = await getApplications();

  return all.where((app) {

    return app.status ==
        WorkflowStatus.pendingRFOApproval;

  }).toList();

}
  // ======================================
  // SUBMIT TO DRFO
  // ======================================

  Future<void> submitToDRFO(

    ApplicationModel application,

  ) async {

    application.status = "Pending DRFO Assignment";

    await updateApplication(

      application,

    );

  }

  // ======================================
  // RETURN TO BFO
  // ======================================

  Future<void> returnToBFO(

    ApplicationModel application,

  ) async {

    application.status = "Pending BFO Inspection";

    await updateApplication(

      application,

    );

  }
    // ======================================
  // DASHBOARD COUNTS
  // ======================================

  Future<Map<String, int>>
      getDashboardCounts() async {

    final db = await _db;

    Future<int> count(

      String status,

    ) async {

      final result = await db.rawQuery(

        "SELECT COUNT(*) as cnt FROM applications WHERE status=?",

        [

          status,

        ],

      );

      return Sqflite.firstIntValue(

            result,

          ) ??
          0;

    }

    final total = Sqflite.firstIntValue(

          await db.rawQuery(

            "SELECT COUNT(*) FROM applications",

          ),

        ) ??
        0;

    return {

  "Total": total,

  "Draft":
      await count("Draft"),

  "Pending DRFO Assignment":
      await count("Pending DRFO Assignment"),

  "Pending BFO Inspection":
      await count("Pending BFO Inspection"),

  "Pending DRFO Verification":
      await count("Pending DRFO Verification"),

  "Pending RFO Approval":
    await count(
      WorkflowStatus.pendingRFOApproval,
    ),

  "Approved":
      await count("Approved"),

  "Rejected":
      await count("Rejected"),

};

  }

  // ======================================
  // UPDATE WORKFLOW
  // ======================================

  Future<void> updateWorkflow({

    required int applicationId,

    required String status,

    required String inspectionMode,

    required int assignedBFO,

  }) async {

    final db = await _db;

    await db.update(

      "applications",

      {

        "status": status,

        "inspectionMode":
            inspectionMode,

        "assignedBFO":
            assignedBFO,

      },

      where: "id=?",

      whereArgs: [

        applicationId,

      ],

    );

  }
  Future<int> getLastTreeNumber(
  int applicationId,
) async {
  final db = await _db;

  final result = await db.query(
    'applications',
    columns: ['lastTreeNumber'],
    where: 'id=?',
    whereArgs: [applicationId],
    limit: 1,
  );

  if (result.isEmpty) return 0;

  return (result.first['lastTreeNumber'] as int?) ?? 0;
}

Future<void> updateLastTreeNumber(
    int applicationId,
    int number,
) async {

  final db = await _db;

  await db.update(
    'applications',
    {
      'lastTreeNumber': number,
    },
    where: 'id=?',
    whereArgs: [applicationId],
  );
}
  }