import 'package:sqflite/sqflite.dart';

import '../database/database_helper.dart';

class TreeVerificationRepository {
  final dbHelper = DatabaseHelper.instance;

  Future<void> saveVerification({
  required int treeId,
  required String verification,
  String? verificationReason,
}) async {
    final db = await dbHelper.database;

    await db.insert(
      "tree_verifications",
      {
        "treeId": treeId,
  "verification": verification,
  "verificationReason": verificationReason,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<String?> getVerification(
    int treeId,
  ) async {
    final db = await dbHelper.database;

    final result = await db.query(
      "tree_verifications",
      where: "treeId=?",
      whereArgs: [treeId],
      limit: 1,
    );

    if (result.isEmpty) {
      return null;
    }

    return result.first["verification"] as String?;
  }
}