import 'package:sqflite/sqflite.dart';

import '../services/database_service.dart';

class ApplicationVerificationRepository {
  final DatabaseService databaseService = DatabaseService();

  Future<void> saveVerification({
    required int applicationId,
    required bool applicationTypeCorrect,
    String? applicationTypeReason,
    required bool gpsCorrect,
    String? gpsReason,
    required bool photosCorrect,
    String? photosReason,
    required bool documentsCorrect,
    String? documentsReason,
    required String verifiedBy,
  }) async {
    final db = await DatabaseService.database;

    await db.insert(
      "application_verifications",
      {
        "applicationId": applicationId,
        "applicationTypeCorrect": applicationTypeCorrect ? 1 : 0,
        "applicationTypeReason": applicationTypeReason,
        "gpsCorrect": gpsCorrect ? 1 : 0,
        "gpsReason": gpsReason,
        "photosCorrect": photosCorrect ? 1 : 0,
        "photosReason": photosReason,
        "documentsCorrect": documentsCorrect ? 1 : 0,
        "documentsReason": documentsReason,
        "verifiedBy": verifiedBy,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<Map<String, dynamic>?> getVerification(
      int applicationId) async {
    final db = await DatabaseService.database;

    final result = await db.query(
      "application_verifications",
      where: "applicationId=?",
      whereArgs: [applicationId],
      limit: 1,
    );

    if (result.isEmpty) {
      return null;
    }

    return result.first;
  }
}